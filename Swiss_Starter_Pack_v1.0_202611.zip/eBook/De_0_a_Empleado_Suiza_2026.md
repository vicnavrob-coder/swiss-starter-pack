# DE 0 A EMPLEADO EN SUIZA
## La Guía Completa para Hispanohablantes (2026)

**Autor:** HispanosEnSuiza
**Versión:** 1.0 (Noviembre 2026)
**Páginas:** 80+

---

## TABLA DE CONTENIDOS

### INTRODUCCIÓN
- Quién debería leer esta guía
- Cómo usar este libro
- Disclaimer importante

### PARTE 1: PREPARACIÓN DESDE TU PAÍS (Antes de llegar)
**Capítulo 1: ¿Estás realmente listo para Suiza?**
- Test de autoevaluación
- Perfiles que triunfan vs perfiles que sufren
- Cuánto dinero necesitas REALMENTE
- Timeline realista: De la decisión al primer día de trabajo

**Capítulo 2: Documentos y Papeles Críticos**
- Checklist completa de documentos
- Apostillas y traducciones: Qué, dónde, cuánto
- Certificados de estudios reconocidos en Suiza
- Antecedentes penales y otros requisitos
- Documentos médicos necesarios

**Capítulo 3: Tu CV Formato Suizo**
- Diferencias CV latino vs CV suizo (ejemplos reales)
- Estructura perfecta del CV suizo
- Qué incluir y qué NUNCA poner
- Foto profesional: Requisitos específicos
- Formato, tipografía y diseño ganador
- 5 ejemplos de CVs exitosos por sector

**Capítulo 4: Carta de Motivación que Funciona**
- Por qué los suizos la leen ANTES que el CV
- Estructura de 3 párrafos imbatible
- Plantilla en alemán con traducciones
- Errores fatales que debes evitar
- 3 ejemplos reales que consiguieron entrevistas

### PARTE 2: BÚSQUEDA ESTRATÉGICA (Conseguir el trabajo)
**Capítulo 5: Dónde Buscar Trabajo (Canales Reales)**
- Portales principales: jobs.ch, jobscout24.ch, indeed.ch
- LinkedIn Suiza: Configuración ganadora
- Redes de contactos: Grupos y comunidades
- Agencias de empleo temporal (las mejores)
- Empresas que contratan hispanohablantes directamente
- Método de aplicación directa que funciona

**Capítulo 6: Sectores con Alta Demanda 2026**
- Hostelería y gastronomía (salarios, requisitos)
- Logística y almacenes (permisos necesarios)
- Construcción (oficios más buscados)
- Salud y cuidado (enfermería, auxiliares)
- IT y tecnología (para perfiles técnicos)
- Limpieza y servicios (punto de entrada común)
- Tabla comparativa: Salario / Alemán requerido / Facilidad entrada

**Capítulo 7: Niveles de Alemán - La Verdad**
- ¿Realmente necesitas alemán?
- Trabajos con A1-A2 (nivel básico)
- Trabajos con B1-B2 (nivel intermedio)
- Dónde aprender alemán ANTES de llegar (gratis y pago)
- Apps que funcionan: Duolingo, Babbel, Seedlang
- Certificados Goethe: ¿Valen la pena?

**Capítulo 8: Estrategia de Aplicación Efectiva**
- Cuántas aplicaciones enviar (número mágico)
- Horarios ideales para aplicar
- Seguimiento sin ser pesado
- Sistema de tracking de aplicaciones
- Qué hacer cuando no responden
- Red flags en ofertas (scams y estafas)

### PARTE 3: ENTREVISTAS (Cerrar la oferta)
**Capítulo 9: Preparación para la Entrevista**
- Tipos de entrevistas en Suiza
- Investigación previa de la empresa
- Qué llevar y cómo vestir
- Puntualidad suiza: Por qué 5 minutos tarde = rechazo
- Video entrevistas: Setup técnico perfecto

**Capítulo 10: Preguntas y Respuestas Clave**
- 20 preguntas más comunes en alemán + respuestas
- Cómo explicar tu situación de extranjero
- Hablar de salario sin arruinarlo
- Tus preguntas al entrevistador (imprescindibles)
- Señales de que va bien vs va mal

**Capítulo 11: Negociación Salarial**
- Rangos salariales por sector y cantón (2026)
- Calculadora: Bruto → Neto real
- Cuándo y cómo negociar
- Beneficios extras a pedir
- Qué hacer si la oferta es baja

**Capítulo 12: El Contrato Suizo**
- Tipos de contratos: Befristet vs Unbefristet
- Cláusulas a revisar antes de firmar
- Periodo de prueba (Probezeit): Qué significa
- Días de vacaciones estándar
- Rescisión y plazos de preaviso
- Red flags contractuales

### PARTE 4: CONSEGUISTE EL TRABAJO - AHORA QUÉ
**Capítulo 13: Permisos de Trabajo**
- Permiso L (corta duración): Proceso completo
- Permiso B (residencia): Cómo obtenerlo
- Permiso G (fronterizo): Si aplica
- Documentos para cada tipo
- Timeline realista por permiso
- Qué hacer si te lo deniegan

**Capítulo 14: Registro en el Gemeinde**
- Qué es el Gemeinde y por qué es CRÍTICO
- Documentos necesarios para registro
- Proceso paso a paso con fotos
- Costos de registro por cantón
- Errores comunes que retrasan el proceso

**Capítulo 15: Cuenta Bancaria Suiza**
- Cambio importante 2026: Neon y Zak
- Bancos que aceptan extranjeros sin permiso B
- Neon vs Revolut vs Wise (comparativa)
- Proceso de apertura paso a paso
- Documentos necesarios
- IBAN suizo vs extranjero: Diferencias críticas
- Twint: La app de pagos que necesitas

**Capítulo 16: Seguros Obligatorios**
- Seguro médico (Krankenversicherung): OBLIGATORIO
- Comparativa: Helsana, CSS, Swica, Sanitas
- Seguro de accidentes (SUVA): Qué cubre
- Cuánto cuestan realmente
- Cómo elegir el nivel de franquicia
- Subsidios para bajos ingresos

**Capítulo 17: Impuestos Primer Año**
- Sistema de impuestos cantonal
- Retención en origen (Quellensteuer)
- Declaración de impuestos anual
- Deducciones permitidas
- Diferencias entre cantones (Zurich vs Zug vs Schwyz)
- Apps para calcular impuestos

**Capítulo 18: Vivienda**
- Mercado de alquiler suizo: La realidad
- Dónde buscar: Homegate, ImmoScout24
- Costo promedio por cantón
- Proceso de aplicación a un piso
- Documentos necesarios (Betreibungsregister, etc.)
- Alternativas: WG (piso compartido), sublets
- Red flags en anuncios (scams comunes)

### PARTE 5: PRIMEROS 90 DÍAS (Integración)
**Capítulo 19: Cultura Laboral Suiza**
- Puntualidad extrema
- Jerarquías y formalidad
- Comunicación directa vs latina
- Horarios y pausas
- Dresscode por sector
- Errores culturales a evitar
- Cómo ganarte a tus colegas suizos

**Capítulo 20: Aprender Alemán Rápido**
- Las mejores academias presenciales por ciudad
- Cursos online efectivos
- Meetups de intercambio de idiomas
- Apps diarias recomendadas
- Alemán suizo vs Hochdeutsch
- Frases imprescindibles para el trabajo

**Capítulo 21: Construir tu Red Social**
- Soledad del emigrante: Cómo combatirla
- Grupos de hispanohablantes por ciudad
- Meetup.com y eventos
- Apps para conocer gente: Bumble BFF, Meetup
- Deportes y hobbies: Punto de entrada
- Voluntariado y clubes

**Capítulo 22: Finanzas y Ahorro**
- Presupuesto mensual realista
- Cómo ahorrar en Suiza (apps, trucos)
- Supermercados baratos: Aldi, Lidl, Denner
- Comer fuera: Dónde y cuánto
- Transporte público: Abonos y descuentos
- Impuestos municipales (Gemeindesteuer)

**Capítulo 23: Salud y Emergencias**
- Sistema de salud suizo explicado
- Cómo ir al médico (Hausarzt)
- Farmacias y medicamentos
- Emergencias: 144 (ambulancia), 112 (general)
- Salud mental: Recursos en español

**Capítulo 24: Ocio y Calidad de Vida**
- Qué hacer en tu tiempo libre
- Senderismo y naturaleza (gratis)
- Museos y cultura
- Viajes por Europa (aprovecha tu ubicación)
- Costo de vida vs calidad de vida

### PARTE 6: SITUACIONES ESPECIALES
**Capítulo 25: Con Familia**
- Reagrupación familiar: Proceso
- Escuelas para hijos
- Guardería (Kita): Costo y disponibilidad
- Adaptación de niños
- Parejas: Ambos trabajando

**Capítulo 26: Estudiar y Trabajar**
- Universidades suizas para extranjeros
- Working student: Límites de horas
- Becas disponibles
- Convalidación de títulos

**Capítulo 27: Emprendimiento**
- Montar negocio en Suiza como extranjero
- Freelance y autónomo
- Permisos necesarios
- Impuestos para autónomos

### PARTE 7: PLAN DE ACCIÓN
**Capítulo 28: Tu Timeline de 90 Días**
- Semanas 1-4: Búsqueda intensiva
- Semanas 5-8: Entrevistas y ofertas
- Semanas 9-12: Llegada e integración
- Checklist semanal detallada

**Capítulo 29: Plan B, C y D**
- Si no consigues trabajo en 3 meses
- Trabajos temporales para sobrevivir
- Agencias de trabajo temporal
- Cuándo considerar otro país

**Capítulo 30: Recursos y Contactos**
- Directorio completo de oficinas
- Apps imprescindibles
- Grupos de WhatsApp/Telegram
- Servicios de apoyo
- Headhunters que hablan español

### ANEXOS
**Anexo A:** Plantillas de emails en alemán
**Anexo B:** Vocabulario laboral alemán-español
**Anexo C:** Tabla de salarios por sector y cantón
**Anexo D:** Comparativa de cantones
**Anexo E:** Checklist maestra de emigración

---

## INTRODUCCIÓN

### ¿Quién debería leer esta guía?

Esta guía es para ti si:
- ✅ Hablas español como idioma principal
- ✅ Estás considerando emigrar a Suiza para trabajar
- ✅ Ya estás en Suiza pero no consigues trabajo
- ✅ Quieres maximizar tus posibilidades de éxito
- ✅ Prefieres información directa sin rodeos

Esta guía NO es para ti si:
- ❌ Buscas fórmulas mágicas sin esfuerzo
- ❌ No estás dispuesto a aprender alemán básico
- ❌ Esperas que Suiza sea como tu país
- ❌ No tienes ahorros mínimos (ver Capítulo 1)

### Cómo usar este libro

**Si aún estás en tu país:**
Lee los capítulos 1-11 COMPLETOS antes de tomar cualquier decisión. El capítulo 1 es especialmente crítico.

**Si ya estás en Suiza buscando trabajo:**
Empieza con los capítulos 5-12. Revisa tu CV y carta de motivación con los capítulos 3-4.

**Si acabas de conseguir trabajo:**
Capítulos 13-18 son tu biblia. No saltes ninguno.

**Si ya llevas tiempo aquí:**
Capítulos 19-24 te ayudarán con integración y optimización.

### Disclaimer importante

Esta guía refleja la situación en **noviembre de 2026**. Las leyes, procedimientos y requisitos pueden cambiar. Siempre verifica información oficial en:
- sem.admin.ch (Secretaría de Estado para Migraciones)
- ch.ch (Portal oficial del gobierno suizo)
- Tu Gemeinde local

Los salarios mencionados son orientativos basados en datos de 2026. Tu situación puede variar según experiencia, idiomas, y negociación.

**Esta guía NO sustituye asesoría legal profesional.**

---

## PARTE 1: PREPARACIÓN DESDE TU PAÍS

### CAPÍTULO 1: ¿ESTÁS REALMENTE LISTO PARA SUIZA?

#### Test de Autoevaluación (Responde honestamente)

**Recursos financieros:**
- [ ] Tengo CHF 5,000+ ahorrados (mínimo recomendado)
- [ ] Puedo sobrevivir 3 meses sin ingresos
- [ ] Tengo plan B si no consigo trabajo

**Idiomas:**
- [ ] Tengo al menos A1 de alemán O estoy dispuesto a aprenderlo
- [ ] Mi inglés es conversacional mínimo
- [ ] Entiendo que el alemán es CRÍTICO a largo plazo

**Expectativas realistas:**
- [ ] Sé que empezaré desde abajo probablemente
- [ ] Acepto que mi título puede no valer igual
- [ ] Entiendo que la cultura suiza es MUY diferente
- [ ] Estoy dispuesto a trabajar duro y adaptarme

**Situación personal:**
- [ ] Tengo apoyo familiar en mi decisión
- [ ] No tengo deudas graves en mi país
- [ ] Estoy mentalmente preparado para soledad inicial
- [ ] Tengo pasaporte vigente por al menos 2 años

**Resultados:**
- **12-15 marcados:** Estás listo. Sigue con la guía.
- **8-11 marcados:** Necesitas mejorar áreas clave primero.
- **0-7 marcados:** Aún no es tu momento. Prepárate mejor.

#### Perfiles que Triunfan vs Perfiles que Sufren

**PERFILES QUE TRIUNFAN:**

**1. El Realista Preparado**
- Edad: 25-40 años
- Idiomas: A2-B1 alemán, inglés conversacional
- Expectativas: "Empiezo de abajo, escalo en 2-3 años"
- Ahorro: CHF 7,000-10,000
- Plan: Trabajo temporal → Permiso B → Trabajo mejor
- **Tasa de éxito: 80-90%**

**2. El Profesional Técnico**
- Sector: IT, ingeniería, salud
- Alemán: Mínimo requerido (inglés fuerte)
- Trabajo desde casa país
- Permiso antes de llegar
- **Tasa de éxito: 90-95%**

**3. El Joven sin Compromisos**
- Edad: 20-28
- Soltero, sin hijos
- Dispuesto a compartir piso
- Trabajos básicos iniciales
- Alemán: Aprende rápido
- **Tasa de éxito: 70-80%**

**PERFILES QUE SUFREN:**

**1. El Soñador sin Plan**
- Cree que con español es suficiente
- Llega sin ahorros
- "Ya veré cuando llegue"
- No investiga antes
- **Tasa de fracaso: 60-70%**

**2. El Profesional Orgulloso**
- "Tengo maestría, no trabajo de eso"
- No acepta empezar desde abajo
- Rechaza trabajos "simples"
- Alemán: "No necesito"
- **Tasa de frustración: 80%**

**3. La Familia sin Red de Seguridad**
- Con hijos pequeños
- Un solo ingreso
- Sin guardería organizada
- Ahorro para 1 mes solo
- **Tasa de estrés extremo: 90%**

#### Cuánto Dinero Necesitas REALMENTE

**ESCENARIO MÍNIMO SUPERVIVENCIA (3 meses):**

```
Alquiler habitación compartida (WG): CHF 600-800/mes × 3 = CHF 2,100
Comida y básicos: CHF 400/mes × 3 = CHF 1,200
Seguro médico: CHF 300/mes × 3 = CHF 900
Transporte: CHF 150/mes × 3 = CHF 450
Imprevistos: CHF 500

TOTAL MÍNIMO: CHF 5,150
```

**ESCENARIO RECOMENDADO (Confortable, 4 meses):**

```
Alquiler estudio 1 ambiente: CHF 1,200/mes × 4 = CHF 4,800
Comida: CHF 600/mes × 4 = CHF 2,400
Seguro médico: CHF 350/mes × 4 = CHF 1,400
Transporte: CHF 200/mes × 4 = CHF 800
Entretenimiento básico: CHF 150/mes × 4 = CHF 600
Depósito piso (Kaution): CHF 3,000
Imprevistos: CHF 1,000

TOTAL RECOMENDADO: CHF 14,000
```

**ESCENARIO FAMILIA (Pareja + 1 hijo, 3 meses):**

```
Alquiler 2 ambientes: CHF 1,800/mes × 3 = CHF 5,400
Comida: CHF 1,000/mes × 3 = CHF 3,000
Seguro médico (3 personas): CHF 700/mes × 3 = CHF 2,100
Transporte: CHF 300/mes × 3 = CHF 900
Guardería (si aplica): CHF 1,500/mes × 3 = CHF 4,500
Depósito: CHF 3,600
Imprevistos: CHF 2,000

TOTAL FAMILIA: CHF 21,500
```

💡 **REGLA DE ORO:** Nunca llegues con menos de CHF 5,000. Ideal: CHF 10,000+.

#### Timeline Realista: De la Decisión al Primer Día de Trabajo

**DESDE TU PAÍS (3-6 meses antes):**

**Mes -6 a -4:**
- Investigación profunda
- Empezar alemán (objetivo A1 mínimo)
- Ahorrar agresivamente
- Preparar documentos
- Conectar con comunidades online

**Mes -3 a -2:**
- CV formato suizo listo
- Cartas de motivación template
- Aplicar a trabajos remotamente
- Buscar alojamiento temporal
- Certificar documentos

**Mes -1:**
- Confirmar alojamiento primeros 30 días
- Comprar vuelo
- Avisar en trabajo actual (si aplica)
- Última ronda de aplicaciones
- Checklist final

**LLEGADA A SUIZA (Primeros 3 meses):**

**Semana 1:**
- Llegar y instalarse
- Registro Gemeinde (CRÍTICO - primeros 14 días)
- Abrir cuenta bancaria
- Activar SIM suiza

**Semana 2-4:**
- Búsqueda intensiva trabajo
- 20-30 aplicaciones/semana
- Networking activo
- Clases alemán (inscribirse)

**Mes 2:**
- Primeras entrevistas
- Ajustar CV según feedback
- Trabajo temporal si no hay fijo
- Construir red social

**Mes 3:**
- Ojalá: Primera oferta
- Negociación y firma
- Permiso de trabajo
- Celebrar 🎉

---

### CAPÍTULO 2: DOCUMENTOS Y PAPELES CRÍTICOS

#### Checklist Completa de Documentos

**OBLIGATORIOS (Necesitas SÍ o SÍ):**

- [ ] **Pasaporte vigente** (mínimo 6 meses validez, idealmente 2+ años)
- [ ] **Foto tipo pasaporte** (formato suizo: 35x45mm, fondo claro, reciente)
- [ ] **CV formato suizo** (máx 2 páginas, con foto)
- [ ] **Certificados de estudios** (título universitario, bachillerato, etc.)
- [ ] **Antecedentes penales** (apostillado y traducido)
- [ ] **Certificado de nacimiento** (apostillado)

**ALTAMENTE RECOMENDADOS:**

- [ ] **Cartas de recomendación** de empleos anteriores (traducidas)
- [ ] **Certificados de trabajo** con fechas y cargos
- [ ] **Certificados de idiomas** (Goethe alemán, IELTS/TOEFL inglés)
- [ ] **Licencia de conducir internacional** (si tienes coche o lo necesitas)
- [ ] **Historial médico** (vacunas, alergias, condiciones crónicas)
- [ ] **Extractos bancarios** (demostrar solvencia, 3 últimos meses)

**SEGÚN SITUACIÓN:**

- [ ] **Partida de matrimonio** (si vienes en pareja, apostillada)
- [ ] **Partidas de nacimiento hijos** (si vienes con familia)
- [ ] **Sentencia de divorcio** (si aplica, apostillada)
- [ ] **Títulos profesionales** (maestría, doctorado, certificaciones)
- [ ] **Portfolio trabajos** (diseñadores, arquitectos, etc.)

#### Apostillas y Traducciones: Qué, Dónde, Cuánto

**¿Qué es una Apostilla?**
Es un sello que certifica que tu documento es genuino a nivel internacional. Suiza reconoce apostillas del Convenio de La Haya.

**Documentos que DEBES apostillar:**
1. Antecedentes penales
2. Certificado de nacimiento
3. Títulos académicos
4. Partida de matrimonio (si aplica)

**Dónde apostillar según tu país:**

**España:**
- Ministerio de Justicia online: https://sede.mjusticia.gob.es
- Costo: ~€5-15 por documento
- Plazo: 7-15 días hábiles

**México:**
- Secretaría de Relaciones Exteriores (SRE)
- Costo: ~MXN 1,000 por documento
- Plazo: 10-20 días hábiles

**Colombia:**
- Ministerio de Relaciones Exteriores
- Costo: ~COP 85,000 por documento
- Plazo: 5-10 días hábiles

**Argentina:**
- Colegio de Escribanos
- Costo: Variable por provincia (~ARS 5,000)
- Plazo: 3-7 días hábiles

**Venezuela:**
- Ministerio del Poder Popular para Relaciones Exteriores
- Costo: Variable
- Plazo: 15-30 días (puede ser más)

**Traducciones Oficiales:**

Suiza requiere traducciones juradas a alemán, francés o italiano según el cantón donde vayas.

**Opciones:**
1. **Traductor jurado en tu país** (más barato generalmente)
2. **Traductor certificado en Suiza** (más aceptado pero caro)

**Costos aproximados:**
- Por página: CHF 30-60 en Suiza
- Por página: €15-30 en España
- Títulos académicos: CHF 100-150 por documento

**Recomendación:** Traduce al menos:
- Título universitario
- Antecedentes penales
- Certificados de trabajo principales

#### Certificados de Estudios Reconocidos en Suiza

**Convalidación de Títulos:**

Para trabajos profesionales (ingeniero, médico, arquitecto, etc.) necesitas convalidar tu título.

**Proceso:**
1. Contactar SERI/SBFI: https://www.sbfi.admin.ch
2. Enviar título apostillado + traducción jurada
3. Pagar tarifa (CHF 550-800)
4. Esperar evaluación (3-6 meses)
5. Recibir reconocimiento o lista de complementos necesarios

**Títulos más fáciles de reconocer:**
- Ingenierías técnicas
- IT y tecnología
- Medicina (con exámenes adicionales)
- Enfermería

**Títulos más difíciles:**
- Derecho (casi imposible)
- Pedagogía/Educación
- Psicología
- Ciencias sociales

💡 **TIP:** Para trabajos no profesionales (logística, hostelería, ventas, etc.) NO necesitas convalidación. Con el título apostillado y traducido basta.

#### Antecedentes Penales: Todo lo que Necesitas Saber

**¿Es obligatorio?**
No para entrar a Suiza como turista. SÍ para:
- Solicitar permiso de trabajo
- Trabajos con menores o vulnerables
- Sector salud, educación, seguridad

**Cómo obtenerlos según país:**

**España:**
- Online en Sede Electrónica del Ministerio de Justicia
- Con certificado digital: Inmediato
- Sin certificado: Solicitar en comisaría
- Costo: Gratis
- Apostillar después (€5)

**México:**
- Portal de servicios de la FGR
- Plazo: 7-15 días
- Costo: Gratis
- Apostillar en SRE

**Colombia:**
- Policía Nacional (online)
- Plazo: 24-48h
- Costo: Gratis
- Apostillar en Min Exteriores

**Argentina:**
- Registro Nacional de Reincidencia
- Plazo: 5-10 días
- Costo: Gratis
- Apostillar en Cancillería

**¿Qué pasa si tengo antecedentes?**
Depende de:
- Gravedad del delito
- Tiempo transcurrido
- Rehabilitación demostrada

Delitos menores antiguos (>10 años) generalmente no son impedimento. Delitos graves o recientes SÍ.

**¿Caducan?**
Los antecedentes penales para Suiza deben tener máximo 6 meses de antigüedad. Planifica bien para no tener que pedirlos dos veces.

### CAPÍTULO 3: TU CV FORMATO SUIZO

#### Diferencias CV Latino vs CV Suizo (Ejemplos Reales)

**❌ CV LATINOAMERICANO TÍPICO (NO funciona en Suiza):**

```
CURRICULUM VITAE

DATOS PERSONALES:
Nombre completo: Juan Carlos Rodríguez Pérez
Fecha de nacimiento: 15 de marzo de 1990 (36 años)
Estado civil: Casado
Nacionalidad: Colombiana
Dirección: Calle Principal 123, Bogotá
Teléfono: +57 300 123 4567
Email: juancarlos_1990@hotmail.com
Cédula: 1234567890

OBJETIVO PROFESIONAL:
Busco una oportunidad laboral que me permita desarrollar mis capacidades
y crecer profesionalmente en un ambiente dinámico y desafiante donde pueda
aportar mis conocimientos y experiencia.

EXPERIENCIA LABORAL:
- Empresa ABC (2018-presente)
  Cargo: Jefe de Ventas
  Responsable de equipo de 5 personas

- Empresa XYZ (2015-2018)
  Cargo: Vendedor

EDUCACIÓN:
- Universidad Nacional (2008-2013)
  Licenciatura en Administración de Empresas

REFERENCIAS:
Disponibles a solicitud
```

**✅ CV SUIZO OPTIMIZADO (SÍ funciona):**

```
Juan Rodriguez
Verkäufer / Sales Professional

Adresse: Bahnhofstrasse 45, 6003 Luzern
Telefon: +41 78 123 45 67
Email: juan.rodriguez@gmail.com
LinkedIn: linkedin.com/in/juanrodriguez-ch
Geburtsdatum: 15.03.1990
Nationalität: Kolumbianisch (B-Bewilligung)

BERUFSERFAHRUNG

Verkaufsleiter | ABC Retail AG, Bogotá                    2018 – 2026
• Management von 5 Verkäufern mit Umsatzsteigerung von 25% in 2 Jahren
• Implementierung CRM-System (Salesforce), Reduzierung Kundenverlust um 15%
• Direkte Kundenbetreuung B2B-Segment (Portfolio CHF 2.5M)
• Budgetverantwortung: CHF 500K/Jahr

Verkäufer | XYZ Electronics, Bogotá                      2015 – 2018
• Verkauf Elektronikprodukte B2C (Jahresziel: 150% erfüllt)
• Key Account Management für Top-10 Kunden
• Produktschulungen für Kunden (Deutsch, Englisch, Spanisch)

AUSBILDUNG

Bachelor of Business Administration                        2008 – 2013
Universidad Nacional de Colombia, Bogotá
Schwerpunkt: Marketing & Vertrieb

SPRACHEN

Spanisch: Muttersprache
Deutsch: B1 (Goethe-Zertifikat, Juli 2026)
Englisch: B2 (fließend)

KOMPETENZEN

Software: Salesforce, SAP, MS Office (Excel fortgeschritten), HubSpot
Verkauf: B2B, B2C, Key Account Management, Cold Calling
Zertifikate: Google Ads Certified, HubSpot Sales

WEITERE INFORMATIONEN

• Führerschein: Kategorie B (EU + CH anerkannt)
• Verfügbarkeit: Sofort
• Arbeitserlaubnis: Permiso B bis Dezember 2027
```

**DIFERENCIAS CLAVE:**

| Aspecto | CV Latino ❌ | CV Suizo ✅ |
|---------|-------------|-------------|
| **Longitud** | 3-4 páginas | 2 páginas máx |
| **Foto** | Generalmente no | SÍ, obligatoria |
| **Información personal** | Excesiva (cédula, estado civil) | Solo relevante laboral |
| **Email** | hotmail/yahoo | Gmail profesional |
| **Objetivo** | Texto genérico largo | Título profesional directo |
| **Experiencia** | Descripciones vagas | Logros con NÚMEROS |
| **Idioma** | Español completo | Alemán (o idioma del cantón) |
| **Fechas** | Mes y año | Formato suizo: MM.YYYY |
| **Referencias** | "Disponibles a solicitud" | Omitir o incluir directamente |

#### Estructura Perfecta del CV Suizo

**ORDEN DE SECCIONES (de arriba a abajo):**

1. **HEADER (Encabezado)**
   - Nombre completo (grande, negrita)
   - Título profesional en alemán
   - Foto profesional (derecha)

2. **CONTACTO**
   - Dirección completa en Suiza
   - Teléfono suizo (+41)
   - Email profesional
   - LinkedIn (si está actualizado)
   - Fecha de nacimiento
   - Nacionalidad + Permiso

3. **BERUFSERFAHRUNG (Experiencia Laboral)**
   - Orden cronológico inverso (más reciente primero)
   - Empresa, Ciudad, País
   - Cargo | Empresa                    Fechas (MM.YYYY – MM.YYYY)
   - 3-5 bullets con logros específicos

4. **AUSBILDUNG (Educación)**
   - Título
   - Universidad, Ciudad, País
   - Fechas

5. **SPRACHEN (Idiomas)**
   - Nivel marco europeo (A1-C2)
   - Certificados si tienes

6. **KOMPETENZEN (Competencias)**
   - Software/herramientas
   - Habilidades técnicas
   - Certificaciones

7. **WEITERE INFORMATIONEN (Opcional)**
   - Licencia de conducir
   - Disponibilidad
   - Permiso de trabajo

#### Qué Incluir y Qué NUNCA Poner

**✅ SÍ INCLUIR:**

- Foto profesional (requisito casi obligatorio)
- Número de teléfono suizo (si no tienes, conseguir SIM prepago)
- Dirección en Suiza (si aún no tienes, usar "Disponible a partir de [fecha]")
- Permiso de trabajo o mención que lo obtendrás con contrato
- Logros cuantificables (%, CHF, números)
- Alemán aunque sea A1 (mencionar que estás aprendiendo)
- LinkedIn actualizado en alemán
- Certificados de idiomas (Goethe, DELE, IELTS)

**❌ NUNCA INCLUIR:**

- ❌ Estado civil (irrelevante y puede generar discriminación)
- ❌ Número de hijos
- ❌ Religión
- ❌ Partido político
- ❌ Número de cédula/DNI del país de origen
- ❌ Hobbies genéricos ("leer", "música") - solo si son relevantes al puesto
- ❌ "Objetivo profesional" largo y genérico
- ❌ Referencias sin nombre (el "disponibles a solicitud" no sirve)
- ❌ Foto casual o selfie
- ❌ Dirección de email no profesional (@hotmail, apodos, números)
- ❌ Experiencia de hace más de 15 años (a menos que sea MUY relevante)
- ❌ Trabajos de 1-2 meses (excepto si es lo único que tienes)

#### Foto Profesional: Requisitos Específicos

**ESPECIFICACIONES TÉCNICAS:**
- Tamaño: 35mm x 45mm (formato pasaporte suizo)
- Posición: Esquina superior derecha del CV
- Calidad: Alta resolución (mínimo 300 DPI)
- Fondo: Blanco o gris claro neutro
- Formato: JPG o PNG

**CÓMO DEBE SER LA FOTO:**

✅ **SÍ:**
- Foto profesional reciente (<6 meses)
- Ropa formal de oficina (camisa, blazer)
- Mirada directa a la cámara
- Expresión seria pero amigable
- Rostro centrado, desde hombros
- Buena iluminación frontal
- Sin sombras marcadas
- Sin gafas de sol

❌ **NO:**
- Foto casual o de vacaciones
- Selfie con móvil
- Foto de cuerpo completo
- Fondos coloridos o con patrones
- Ropa informal (camiseta, ropa deportiva)
- Foto grupal recortada
- Filtros o ediciones excesivas
- Foto de hace años

**DÓNDE CONSEGUIR LA FOTO:**

1. **Fotomatón profesional** (más barato)
   - En estaciones de tren: CHF 8-12
   - Calidad buena para CV

2. **Estudio fotográfico** (mejor calidad)
   - Costo: CHF 30-50
   - Te dan versión digital + impresa
   - Buscar "Passfoto" en Google Maps

3. **DIY con móvil** (solo si no tienes presupuesto)
   - Luz natural, pared blanca
   - Ropa formal
   - Usar trípode o timer
   - Editar mínimamente (solo luz/contraste)

💡 **TIP:** La misma foto puedes usarla para LinkedIn, permisos, y otros trámites. Vale la pena invertir en una buena.

#### Formato, Tipografía y Diseño Ganador

**DISEÑO GENERAL:**

**Opción 1: Clásico Minimalista (Más seguro)**
- Fondo blanco
- Texto negro
- Una columna principal
- Header con nombre en grande
- Espaciado generoso entre secciones

**Opción 2: Moderno con Color (Para sectores creativos/tech)**
- Header con color sólido (azul oscuro, gris, verde profesional)
- Texto negro sobre blanco
- Líneas divisorias sutiles
- Iconos minimalistas para contacto

**TIPOGRAFÍA:**

**Fuentes recomendadas:**
- Arial (la más segura, reconocida por ATS)
- Helvetica (muy suiza)
- Calibri (moderna y limpia)
- Open Sans (si es PDF)

**Evitar:**
- Times New Roman (muy anticuado)
- Comic Sans (obviamente)
- Fuentes decorativas o manuscritas

**Tamaños:**
- Nombre: 18-22pt
- Título profesional: 12-14pt
- Encabezados secciones: 11-12pt BOLD
- Texto normal: 10-11pt
- Contacto: 9-10pt

**MÁRGENES Y ESPACIADO:**
- Márgenes: 1.5-2cm por lado
- Interlineado: 1.15 o 1.2
- Espacio entre secciones: 0.5-1cm
- Espacio entre bullets: 0.2-0.3cm

**ATS-FRIENDLY (Applicant Tracking System):**

Los ATS son robots que escanean tu CV antes de que un humano lo vea.

**Para pasar el ATS:**
✅ Usar formato .docx o .pdf con texto seleccionable
✅ Evitar tablas complejas
✅ Evitar headers/footers con información crítica
✅ Usar encabezados estándar (Berufserfahrung, no "Mi Camino Laboral")
✅ Incluir palabras clave del anuncio de trabajo
✅ Evitar imágenes con texto incrustado

---

### CAPÍTULO 4: CARTA DE MOTIVACIÓN QUE FUNCIONA

#### Por qué los Suizos la Leen ANTES que el CV

**En Suiza la carta de motivación (Motivationsschreiben / Lettre de motivation) es CRÍTICA.**

**Diferencias culturales:**

**Latino:** CV = 80% importancia, Carta = 20%
**Suizo:** Carta = 60% importancia, CV = 40%

**¿Por qué?**
1. Los suizos valoran la **personalización** - quieren saber por qué ESA empresa
2. Evalúan tu nivel de **alemán escrito** antes de llamarte
3. Buscan **motivación genuina**, no aplicaciones masivas
4. Quieren ver si entiendes su **cultura laboral**

❗ **REGLA DE ORO:** Una carta genérica = CV descartado sin leer.

#### Estructura de 3 Párrafos Imbatible

**ENCABEZADO (Header):**

```
[Tu nombre completo]
[Dirección en Suiza]
[Teléfono suizo]
[Email]

                                    [Ciudad], [Fecha en formato suizo: 08.11.2026]

[Nombre empresa]
[Departamento / Persona contacto]
[Dirección empresa]
[Código postal y ciudad]

Betreff: Bewerbung als [Cargo exacto del anuncio] - Referenz [número si hay]
```

**PÁRRAFO 1: EL GANCHO (3-4 líneas)**

Objetivo: Captar atención + demostrar que conoces la empresa

**Estructura:**
- Frase de apertura directa
- Por qué esta empresa específicamente
- Cómo te enteraste de la oferta

**❌ MAL:**
```
Sehr geehrte Damen und Herren,

Mit großem Interesse habe ich Ihre Stellenanzeige gelesen. Ich bin sehr motiviert
und fleißig und würde gerne für Ihr Unternehmen arbeiten.
```
(Genérico, aburrido, podría ser para cualquier empresa)

**✅ BIEN:**
```
Sehr geehrte Frau Müller,

Ihre Innovation im Bereich nachhaltiger Logistik und die Auszeichnung "Best Employer
2026" haben meine Aufmerksamkeit geweckt. Als erfahrener Lagerist mit 5 Jahren
Erfahrung in SAP WM möchte ich Teil Ihres wachsenden Teams in Zürich werden.
```
(Específico, muestra investigación, conecta experiencia con la empresa)

**PÁRRAFO 2: EL VALOR (5-6 líneas)**

Objetivo: Demostrar que eres el candidato ideal con EVIDENCIAS

**Estructura:**
- Tu experiencia relevante con números
- Habilidades que coinciden con el anuncio
- Logro específico que prueba tu valor

**❌ MAL:**
```
Ich habe viel Erfahrung im Verkauf und bin ein Teamplayer. Ich lerne schnell
und bin sehr flexibel. Ich bin sicher, dass ich gut zu Ihrem Team passe.
```
(Vago, sin pruebas, puras afirmaciones)

**✅ BIEN:**
```
In meiner aktuellen Position bei ABC Logistics habe ich ein Team von 8 Mitarbeitern
geleitet und die Kommissionierungszeit um 30% reduziert. Durch die Implementierung
eines neuen WMS-Systems konnte ich die Fehlerquote von 5% auf 1,2% senken.
Meine Deutschkenntnisse (B1-Niveau, Goethe-Zertifikat) ermöglichen mir bereits
jetzt eine reibungslose Kommunikation mit Kollegen und Lieferanten.
```
(Concreto, con números, evidencia de impacto, menciona alemán)

**PÁRRAFO 3: EL CIERRE (2-3 líneas)**

Objetivo: Call-to-action + disponibilidad + agradecimiento

**Estructura:**
- Disponibilidad para entrevista
- Fecha de inicio posible
- Agradecimiento formal

**❌ MAL:**
```
Ich freue mich auf Ihre Antwort.

Mit freundlichen Grüßen,
Juan Rodriguez
```
(Pasivo, sin acción, mínimo esfuerzo)

**✅ BIEN:**
```
Gerne stelle ich Ihnen meine Qualifikationen persönlich vor und stehe ab dem
15.12.2026 zur Verfügung. Für ein Vorstellungsgespräch bin ich jederzeit verfügbar.

Ich freue mich auf Ihre positive Rückmeldung.

Mit freundlichen Grüßen

Juan Rodriguez

Anlagen: Lebenslauf, Zeugnisse, Zertifikate
```
(Proactivo, fechas claras, menciona anexos)

#### Plantilla en Alemán con Traducciones

**PLANTILLA COMPLETA - SECTOR LOGÍSTICA:**

```
Juan Rodriguez
Bahnhofstrasse 45
6003 Luzern
+41 78 123 45 67
juan.rodriguez@gmail.com

                                                        Luzern, 08.11.2026

Logistik Schweiz AG
Personalabteilung
Frau Sandra Müller
Industriestrasse 12
8005 Zürich

Betreff: Bewerbung als Lagerist (100%) - Referenz LSA-2026-089


Sehr geehrte Frau Müller,

[GANCHO]
Ihre Stellenanzeige für einen Lageristen mit SAP-Kenntnissen hat mein Interesse
geweckt. Als erfahrener Logistikmitarbeiter mit 5 Jahren Erfahrung in Hochregallagern
und fundierten SAP WM-Kenntnissen bin ich überzeugt, dass ich Ihr Team optimal
verstärken kann.

[VALOR]
In meiner aktuellen Position bei ABC Logistics in Kolumbien leite ich ein Team
von 8 Mitarbeitern und bin verantwortlich für die Ein- und Auslagerung von ca.
500 Paletten täglich. Durch die Optimierung unserer Kommissionierungsprozesse
konnte ich die Durchlaufzeit um 25% reduzieren und gleichzeitig die Fehlerquote
von 4,5% auf 1,1% senken. Meine Erfahrung mit Flurförderzeugen (Staplerschein
Kategorie R1-R3) und WMS-Systemen ermöglicht mir einen sofortigen produktiven
Einsatz. Meine Deutschkenntnisse auf B1-Niveau (Goethe-Zertifikat, Juli 2026)
und fließendes Englisch garantieren eine reibungslose Kommunikation im Team.

[CIERRE]
Mit meiner B-Bewilligung kann ich ab dem 01.01.2027 bei Ihnen starten. Gerne
überzeuge ich Sie in einem persönlichen Gespräch von meiner Motivation und meinen
Fähigkeiten.

Ich freue mich auf Ihre positive Rückmeldung.

Mit freundlichen Grüßen


Juan Rodriguez


Anlagen:
- Lebenslauf
- Arbeitszeugnisse
- Goethe-Zertifikat B1
- Staplerschein
- B-Bewilligung (Kopie)
```

**TRADUCCIÓN AL ESPAÑOL (Para que entiendas):**

```
Asunto: Solicitud para Empleado de Almacén (100%) - Referencia LSA-2026-089

Estimada Sra. Müller,

[GANCHO]
Su anuncio para un empleado de almacén con conocimientos de SAP ha despertado
mi interés. Como empleado logístico experimentado con 5 años de experiencia en
almacenes de gran altura y sólidos conocimientos de SAP WM, estoy convencido de
que puedo reforzar óptimamente su equipo.

[VALOR]
En mi posición actual en ABC Logistics en Colombia, dirijo un equipo de 8 empleados
y soy responsable del almacenamiento de aproximadamente 500 pallets diarios.
Mediante la optimización de nuestros procesos de picking, pude reducir el tiempo
de procesamiento en un 25% y al mismo tiempo disminuir la tasa de error del 4,5%
al 1,1%. Mi experiencia con montacargas (licencia categorías R1-R3) y sistemas
WMS me permite un despliegue productivo inmediato. Mis conocimientos de alemán
nivel B1 (certificado Goethe, julio 2026) e inglés fluido garantizan una
comunicación fluida en el equipo.

[CIERRE]
Con mi permiso B puedo empezar el 01.01.2027. Con gusto le convenceré de mi
motivación y capacidades en una entrevista personal.

Espero su respuesta positiva.

Cordialmente,
Juan Rodriguez

Anexos:
- CV
- Certificados laborales
- Certificado Goethe B1
- Licencia montacargas
- Permiso B (copia)
```

#### Errores Fatales que Debes Evitar

**❌ ERROR #1: Carta genérica**
"Muy estimados señores, solicito el puesto anunciado..."
→ El reclutador lo detecta en 3 segundos. DESCARTADO.

**✅ SOLUCIÓN:**
- Menciona el nombre de la empresa 2-3 veces
- Referencia algo específico (producto, premio, noticia reciente)
- Personaliza cada carta (sí, es más trabajo, pero funciona)

**❌ ERROR #2: Alemán con Google Translate obvio**
"Ich bin sehr gut in teams arbeit und habe viele skills"
→ Errores gramaticales + anglicismos = no hablas alemán

**✅ SOLUCIÓN:**
- Usar DeepL (mejor que Google)
- Pedir a alguien nativo que revise
- Contratar corrección en Fiverr (CHF 10-20)
- Usar frases template de alemán formal

**❌ ERROR #3: Demasiado larga (>1 página)**
→ Los suizos valoran la concisión

**✅ SOLUCIÓN:**
- Máximo 1 página A4
- 3 párrafos de 3-6 líneas cada uno
- Sin relleno ni repetición

**❌ ERROR #4: Hablar de lo que la empresa puede hacer por ti**
"Busco una oportunidad para crecer profesionalmente y desarrollar mi carrera..."
→ Al empleador no le importa tu desarrollo, le importa qué aportas

**✅ SOLUCIÓN:**
- Enfoque: qué problema del empleador puedes resolver
- Qué valor concreto aportas
- Cómo les ayudarás a alcanzar sus objetivos

**❌ ERROR #5: No mencionar tu situación de permiso**
→ La empresa asume que no tienes permiso y descarta

**✅ SOLUCIÓN:**
- Si tienes permiso B: "Mit meiner B-Bewilligung kann ich sofort starten"
- Si tienes oferta pero no permiso: "Ich verfüge über eine Arbeitszusage und kann die Arbeitserlaubnis kurzfristig erhalten"
- Si eres UE: "Als EU-Bürger benötige ich keine Arbeitserlaubnis"

**❌ ERROR #6: Email de envío descuidado**

Asunto: "CV"
Cuerpo: "Adjunto mi CV para el puesto. Saludos, Juan"

→ Primera impresión = última impresión

**✅ SOLUCIÓN:**

Asunto: Bewerbung Lagerist (Ref. LSA-2026-089) - Juan Rodriguez

Cuerpo:
```
Sehr geehrte Frau Müller,

anbei sende ich Ihnen meine vollständigen Bewerbungsunterlagen für die Position
als Lagerist (Referenz LSA-2026-089).

Mit freundlichen Grüßen
Juan Rodriguez

Anlagen:
- Motivationsschreiben
- Lebenslauf
- Zeugnisse
```

## PARTE 2: BÚSQUEDA ESTRATÉGICA

### CAPÍTULO 5: DÓNDE BUSCAR TRABAJO (CANALES REALES)

#### Portales Principales

**1. JOBS.CH** ⭐⭐⭐⭐⭐ (EL MÁS IMPORTANTE)

**Por qué es el #1:**
- Portal líder en Suiza alemana
- 90% de empresas suizas publican aquí
- Interfaz en alemán, francés e inglés
- App móvil excelente

**Cómo usarlo efectivamente:**

1. Crear perfil completo (100% completion)
   - CV en alemán subido
   - Carta de motivación template
   - Agregar "Alerta de empleo" por email

2. Configurar búsqueda inteligente:
   - Por cantón: Zürich, Luzern, Aargau (más ofertas)
   - Por nivel alemán: Filtrar "Grundkenntnisse" (básico)
   - Por salario: Mínimo CHF 4,000/mes
   - Por permiso: "Ausländer mit Aufenthaltsbewilligung"

3. Aplicar en las primeras 48h de publicación
   - Las ofertas más recientes tienen menos competencia
   - Después de 1 semana, la respuesta es casi cero

**Sectores con más ofertas en jobs.ch (2026):**
- Gastgewerbe (hostelería): 3,500+ ofertas activas
- Logistik (logística): 2,800+ ofertas
- Bau (construcción): 2,100+ ofertas
- Verkauf (ventas): 1,900+ ofertas
- Gesundheitswesen (salud): 1,700+ ofertas

---

**2. INDEED.CH** ⭐⭐⭐⭐

**Ventajas:**
- Interfaz familiar (igual que en LATAM)
- Muchas ofertas internacionales
- Filtro por salario visible
- Reviews de empresas (útil para detectar red flags)

**Cómo diferenciarse:**
- Subir CV en alemán E inglés (2 versiones)
- Usar "Easy Apply" para aplicar rápido
- Leer reviews de empresa ANTES de aplicar
- Configurar alertas diarias por email

**Truco:** Indeed indexa ofertas de otros portales. A veces verás la misma oferta que en jobs.ch. SIEMPRE aplica directo en la web de la empresa para evitar duplicados.

---

**3. JOBSCOUT24.CH** ⭐⭐⭐⭐

**Características:**
- Portal de JobCloud (mismo dueño que jobs.ch)
- Enfocado en profesionales con experiencia
- Menos ofertas básicas, más especializadas
- Test de personalidad integrado (puede ayudarte)

**Ideal para:**
- Perfiles con título universitario
- Profesionales IT, ingeniería, salud
- Búsqueda de puestos mid-level

**No tan útil para:**
- Trabajos entry-level
- Puestos sin requisitos de alemán

---

**4. LINKEDIN** ⭐⭐⭐⭐ (Networking + empleos)

**Por qué LinkedIn Suiza es DIFERENTE:**

En LATAM: LinkedIn = CV online
En Suiza: LinkedIn = Red profesional activa

**Configuración ganadora:**

1. **Perfil optimizado en alemán:**
   - Headline: "Verkäufer | 5+ Jahre Erfahrung | B1 Deutsch | Auf der Suche nach neuen Herausforderungen in der Schweiz"
   - About: 3 párrafos en alemán (usa DeepL)
   - Experiencia: Con logros y números (igual que CV)

2. **Banner de portada:**
   - Foto de Suiza (montañas, lago, ciudad suiza)
   - Mensaje: "Open to work in Switzerland 🇨🇭"

3. **Localización:**
   - Location: "Zürich, Schweiz" (aunque no estés aún)
   - Esto hace que aparezcas en búsquedas de recruiters

4. **Estrategia de aplicación:**
   - NUNCA uses "Easy Apply" de LinkedIn
   - Usa LinkedIn para encontrar el nombre del recruiter
   - Búscalo en la web de la empresa
   - Envía email directo mencionando que lo viste en LinkedIn

5. **Networking activo:**
   - Conectar con recruiters de agencias suizas
   - Seguir empresas que te interesan
   - Comentar posts (en alemán) de empresas target
   - Unirte a grupos: "Expats in Switzerland", "Jobs in Zürich"

---

**5. JOBAGENT.CH** ⭐⭐⭐

**Qué es:**
- Agregador de ofertas de 20+ portales
- Te ahorra buscar en muchos sitios
- Alertas automáticas potentes

**Cómo usarlo:**
- No para aplicar (redirige a portal original)
- SÍ para monitorear mercado
- Configurar alertas muy específicas

---

#### Agencias de Empleo Temporal (Las Mejores)

**Las agencias temporales son el SECRETO para entrar rápido al mercado suizo.**

**¿Por qué funcionan?**
1. No necesitas alemán perfecto
2. Te dan permiso de trabajo más fácil
3. Pagas tus cuotas sociales
4. Muchas veces te contratan después (30-40% de casos)

**TOP 5 AGENCIAS (Por sector):**

**1. ADECCO SWITZERLAND** ⭐⭐⭐⭐⭐
- Sectores: Logística, producción, oficina
- Presencia: Toda Suiza
- Ventajas: Contratan a extranjeros regularmente
- Alemán: A2 mínimo (depende del puesto)
- Web: adecco.ch
- **Tip:** Ir en persona a la oficina con CV impreso. Mejor que online.

**2. MANPOWER**
- Sectores: Industria, técnicos, IT
- Buenos salarios (CHF 25-30/hora para perfiles técnicos)
- Alemán: B1 recomendado
- Web: manpower.ch

**3. RANDSTAD**
- Sectores: Hostelería, retail, logística
- Muchas ofertas para hispanohablantes
- Alemán: A2 suficiente
- Web: randstad.ch
- **Tip:** Tienen programa "Randstad Inhouse" - trabajas dentro de grandes empresas (Migros, Coop)

**4. KELLY SERVICES**
- Sectores: IT, finanzas, administrativo
- Salarios altos
- Alemán: B2+ generalmente
- Web: kellyservices.ch

**5. JOBCLOUD (Portal + Agencia)**
- Sectores: Todos
- Web: jobup.ch
- Modelo híbrido: Portal + colocación

**PROCESO CON AGENCIAS (Paso a paso):**

1. **Registrarse online**
   - CV en alemán
   - Carta motivación estándar
   - Especificar "disponible inmediatamente"

2. **Llamada inicial** (10-15 min)
   - Evalúan alemán hablado
   - Preguntan experiencia
   - Definen salario esperado

3. **Entrevista presencial** (30 min)
   - Llevar originales: Pasaporte, permiso, CV, certificados
   - Test básico (Excel, alemán, dependiendo del sector)
   - Firmar contrato marco

4. **Asignaciones**
   - Te llaman cuando hay match
   - Misiones: 1 día, 1 semana, 3 meses, etc.
   - Salario semanal o quincenal

**SALARIOS AGENCIAS TEMP (Promedios 2026):**

| Sector | CHF/hora | CHF/mes (100%) |
|--------|----------|----------------|
| Limpieza | 22-25 | 3,800-4,300 |
| Logística/Almacén | 24-28 | 4,150-4,850 |
| Producción | 25-30 | 4,300-5,200 |
| Gastronomía | 23-26 | 3,980-4,500 |
| Retail/Ventas | 25-28 | 4,300-4,850 |
| Oficina/Admin | 28-35 | 4,850-6,050 |

💡 **HACK:** Las agencias te pagan MEJOR que un trabajo directo entry-level, porque ellas facturan más a la empresa.

---

#### Empresas que Contratan Hispanohablantes Directamente

**GRANDES CADENAS (Siempre contratan):**

**MIGROS** (Supermercados + Retail)
- Puestos: Cajero, reponedor, logística, limpieza
- Alemán: A2 mínimo
- Aplicar: migros.ch/karriere
- Salario: CHF 4,200-4,800/mes
- **Ventaja:** Dan formación interna en alemán

**COOP** (Supermercados)
- Similar a Migros
- Aplicar: coop.ch/jobs
- Buscar "Mitarbeiter Verkauf" o "Logistik"

**LIDL / ALDI SUISSE**
- Alemán: A2-B1
- Salario: CHF 4,500-5,000/mes
- **Ventaja:** Modelo alemán, acostumbrados a extranjeros
- Aplicar: lidl.ch/karriere

**IKEA SCHWEIZ**
- Puestos: Ventas, logística, restaurante
- Alemán: B1 (evalúan en entrevista)
- Salario: CHF 4,200-4,600
- Aplicar: ikea.ch/karriere

**HOTELS / HOSTELERÍA:**

**MÖVENPICK, IBIS, NOVOTEL** (Cadenas Accor)
- Alemán: A2-B1 + inglés
- Puestos: Housekeeping, cocina, recepción
- Salario: CHF 4,000-5,500 (depende del puesto)
- Muchos extranjeros ya trabajando

**MCDONALDS / BURGER KING**
- Alemán: A2 suficiente
- Siempre contratan
- Salario: CHF 3,900-4,300
- Buen punto de entrada para jóvenes

---

#### Método de Aplicación Directa que Funciona

**¿Qué es la aplicación directa (Initiativbewerbung)?**
Enviar tu CV a empresas aunque NO tengan ofertas publicadas.

**¿Funciona en Suiza?**
SÍ, especialmente en:
- Pequeñas empresas (< 50 empleados)
- Sectores con escasez (logística, construcción, hostelería)
- Empresas en cantones pequeños (menos competencia)

**PROCESO:**

1. **Identificar empresas target** (20-30 empresas)
   - Buscar en Google Maps: "Logistikunternehmen Luzern"
   - Filtrar por tamaño (< 100 empleados = más probabilidad)
   - Verificar que tengan web con email de contacto

2. **Investigar mínimo sobre cada empresa**
   - Qué hacen
   - Cuántos empleados
   - Noticias recientes

3. **Email de aplicación directa**

**Template:**

```
Betreff: Initiativbewerbung als Lagerist - Juan Rodriguez

Sehr geehrte Damen und Herren,

als erfahrener Logistikmitarbeiter mit 5 Jahren Erfahrung im Hochregallager und
SAP WM-Kenntnissen möchte ich mich initiativ bei Ihrem Unternehmen bewerben.

Meine Qualifikationen:
• 5 Jahre Erfahrung Ein-/Auslagerung (500+ Paletten/Tag)
• SAP WM und WMS-Systeme
• Staplerschein R1-R3
• Deutsch B1, Englisch B2, Spanisch Muttersprache
• B-Bewilligung Luzern

Ich bin ab sofort verfügbar und würde mich freuen, Ihr Team zu verstärken.

Mit freundlichen Grüßen
Juan Rodriguez

Anlagen: CV, Zertifikate
```

4. **Seguimiento (1 semana después)**

Si no responden:

```
Betreff: Nachfrage - Initiativbewerbung Juan Rodriguez

Sehr geehrte Damen und Herren,

vor einer Woche habe ich Ihnen meine Bewerbungsunterlagen zugeschickt.
Ich möchte höflich nachfragen, ob Sie Interesse an einem persönlichen Gespräch haben.

Ich bin unter +41 78 123 45 67 oder juan.rodriguez@gmail.com jederzeit erreichbar.

Mit freundlichen Grüßen
Juan Rodriguez
```

**Tasa de éxito:** 5-10% responden positivamente. Por eso necesitas volumen (20-30 empresas).

---

### CAPÍTULO 6: SECTORES CON ALTA DEMANDA 2026

#### Hostelería y Gastronomía

**REALIDAD DEL SECTOR:**
- Sector #1 para extranjeros
- SIEMPRE faltan empleados
- Alemán básico (A2) suficiente en cocina
- Salarios: CHF 4,000-5,500/mes

**PUESTOS MÁS DEMANDADOS:**

**1. KOCH / COCINERO**
- Salario: CHF 4,500-6,000/mes
- Alemán: A2-B1
- Requisitos: Experiencia mínima 2 años
- Dónde buscar: gastrojobs.ch, hotelcareer.ch
- **Ventaja:** Con experiencia en cocina latina, tienes valor único

**2. SERVICEMITARBEITER / MESERO**
- Salario: CHF 4,000-4,800/mes + propinas (CHF 200-500)
- Alemán: B1 mínimo (hablas con clientes)
- Requisitos: Experiencia + actitud
- **Tip:** Hablar inglés también suma (turistas)

**3. HOUSEKEEPING / LIMPIEZA HOTEL**
- Salario: CHF 3,900-4,500/mes
- Alemán: A1-A2 suficiente
- Requisitos: Ninguno especial
- Demanda: MUY ALTA (hoteles siempre buscan)
- **Mejor para:** Entrada rápida al mercado

**4. BARISTA / CAFÉ**
- Salario: CHF 4,200-4,700/mes
- Alemán: B1 (clientes suizos exigentes)
- Requisitos: Curso barista ayuda
- Cadenas que contratan: Starbucks, Tibits, Brezelkönig

**DÓNDE APLICAR:**
- gastrojobs.ch ⭐⭐⭐⭐⭐
- hotelcareer.ch
- hotellejob.ch (Suiza romande)
- Direct: Web de hoteles grandes

**CIUDADES CON MÁS DEMANDA:**
1. Zürich (turismo + business)
2. Luzern (turismo internacional)
3. Interlaken (temporada alta verano)
4. St. Moritz (temporada invierno + verano)
5. Genève (hoteles de lujo)

---

#### Logística y Almacenes

**POR QUÉ HAY TANTA DEMANDA:**
- Suiza = hub logístico de Europa
- E-commerce en crecimiento
- Empresas como Digitec, Galaxus, Amazon Suiza expandiéndose
- Población suiza NO quiere trabajar de noche/turnos

**SALARIOS SECTOR LOGÍSTICA:**

| Puesto | Salario/mes | Alemán | Requisitos |
|--------|-------------|--------|------------|
| Lagerist (almacenero) | CHF 4,300-5,000 | A2-B1 | Ninguno |
| Staplerfahrer (con montacargas) | CHF 4,800-5,500 | A2 | Licencia R1-R3 |
| Kommissionierer (picker) | CHF 4,200-4,800 | A1-A2 | Ninguno |
| Logistikleiter (supervisor) | CHF 5,500-7,000 | B1-B2 | Experiencia liderazgo |
| Chauffeur (conductor) | CHF 5,000-6,000 | B1 | Licencia C suiza |

**EMPRESAS GRANDES QUE SIEMPRE CONTRATAN:**

**POST LOGISTICS**
- Logística de Correos Suiza
- 7,000+ empleados
- Aplicar: post.ch/jobs
- Ventaja: Empresa estatal, buen empleador

**DHL / KÜHNE + NAGEL**
- Logística internacional
- Muchos almacenes en Suiza
- Alemán: A2-B1
- Salario: CHF 4,500-5,200

**PLANZER / CAMION TRANSPORT**
- Transporte y almacenaje
- Contratan extranjeros regularmente
- Sedes: Zürich, Bern, Basel, Luzern

**MIGROS LOGISTIK / COOP LOGISTIK**
- Almacenes gigantes
- 24/7 operación
- Turnos noche pagan + 15-20%
- Aplicar: migros-gruppe.ch, coop.ch

**GALAXUS / DIGITEC (E-COMMERCE)**
- E-commerce #1 en Suiza
- Almacén en Wohlen (Aargau)
- Ambiente joven, internacional
- Salario: CHF 4,500-5,000
- Aplicar: digitecgalaxus.ch/jobs

**CERTIFICACIONES QUE SUMAN:**
1. **Staplerschein (Licencia montacargas)** ⭐⭐⭐⭐⭐
   - Dónde: Arbeitssicherheit Schweiz, SUVA
   - Costo: CHF 400-600
   - Duración: 2-3 días
   - ROI: Salario +CHF 500-700/mes

2. **SAP WM (Warehouse Management)**
   - Curso online: Udemy, Coursera
   - Costo: CHF 50-150
   - Valor: Alto (muchas empresas usan SAP)

---

#### Construcción

**CONTEXTO:**
- Construcción en Suiza = salarios altos
- Mucha demanda, poca oferta de trabajadores
- Trabajo duro pero bien pagado

**OFICIOS MÁS BUSCADOS 2026:**

**1. BAUARBEITER (Peón de construcción)**
- Salario: CHF 4,500-5,500/mes
- Alemán: A1-A2 (órdenes básicas)
- Requisitos: Fuerza física, experiencia mínima
- **Sin título necesario**

**2. MAURER (Albañil)**
- Salario: CHF 5,500-7,000/mes
- Alemán: A2-B1
- Requisitos: Experiencia demostrable

**3. ELEKTRIKER (Electricista)**
- Salario: CHF 6,000-8,000/mes
- Alemán: B1-B2
- Requisitos: Título reconocido + experiencia
- **Alta demanda, buen salario**

**4. SANITÄRINSTALLATEUR (Fontanero)**
- Salario: CHF 5,800-7,500/mes
- Alemán: B1
- Requisitos: Título + 3 años experiencia

**EMPRESAS GRANDES:**
- Implenia (la más grande)
- Frutiger AG
- Marti AG
- Aplicar: bauberufe.ch, bau-stellen.ch

**IMPORTANTE:**
- Trabajo 100% presencial
- Clima: Invierno duro (-5°C a -15°C)
- Horarios: 7:00-17:00 generalmente
- Seguridad: SUVA muy estricto (capacitaciones obligatorias)

---

### CAPÍTULO 7: NIVELES DE ALEMÁN - LA VERDAD

#### ¿Realmente Necesitas Alemán?

**LA RESPUESTA CORTA: Depende.**

**LA RESPUESTA LARGA:**

**SIN ALEMÁN (Solo español/inglés):**
Puedes conseguir trabajo en:
- Limpieza (A1 suficiente)
- Cocina (A1-A2)
- Almacén con 0 contacto cliente (A1)
- Construcción peón (A1)
- Algunas empresas tech (si tu inglés es C1+)

**Salario techo:** CHF 4,500-5,000/mes
**Progresión:** Limitada

**CON ALEMÁN A2-B1:**
Se abren:
- Servicio al cliente
- Ventas básicas
- Oficina (data entry, admin básico)
- Conducción (Chauffeur)
- Supervisor/team lead

**Salario techo:** CHF 5,500-6,500/mes
**Progresión:** Media

**CON ALEMÁN B2-C1:**
Accedes a:
- Profesionales (tu título cuenta)
- Management
- Ventas complejas
- Cualquier sector

**Salario techo:** CHF 7,000-12,000+/mes
**Progresión:** Alta

**CONCLUSIÓN:**
Sí necesitas alemán para prosperar en Suiza a largo plazo. Pero NO necesitas B2 para empezar.

**ESTRATEGIA INTELIGENTE:**
1. Aprende A1-A2 en tu país (3-6 meses con disciplina)
2. Consigue trabajo básico en Suiza con A2
3. Estudia alemán en Suiza (más barato que en tu país, inmersión total)
4. En 1-2 años llegas a B1-B2
5. Cambias a trabajo mejor

---

#### Trabajos con A1-A2 (Nivel Básico)

**QUÉ SIGNIFICA A1-A2:**
- A1: "Ich heiße Juan. Ich komme aus Kolumbien. Ich spreche Spanisch und ein bisschen Deutsch."
- A2: Puedes tener conversaciones básicas sobre temas cotidianos, entender instrucciones simples

**TRABAJOS REALISTAS:**

| Puesto | Alemán | Salario | Comentarios |
|--------|--------|---------|-------------|
| Housekeeping | A1 | CHF 3,900-4,500 | Instrucciones básicas |
| Küchenhilfe (ayudante cocina) | A1-A2 | CHF 4,200-4,800 | Cocina = menos contacto |
| Lagerist (almacén sin cliente) | A1-A2 | CHF 4,300-5,000 | Seguir órdenes SAP |
| Reinigung (limpieza) | A1 | CHF 3,800-4,400 | Trabajo individual |
| Produktionsmitarbeiter (producción) | A2 | CHF 4,500-5,200 | Línea de producción |
| Bauhelfer (ayudante construcción) | A1-A2 | CHF 4,500-5,500 | Órdenes simples |

---

#### Dónde Aprender Alemán ANTES de Llegar

**APPS (GRATIS O CASI):**

**1. DUOLINGO** ⭐⭐⭐
- Costo: Gratis (o CHF 7/mes premium)
- Tiempo: 15-30 min/día
- Llegar a: A1 en 2-3 meses
- **Pro:** Gamificado, adictivo
- **Contra:** No practicas hablar

**2. BABBEL** ⭐⭐⭐⭐
- Costo: CHF 6-10/mes
- Tiempo: 30 min/día
- Llegar a: A2 en 4-6 meses
- **Pro:** Más completo que Duolingo
- **Contra:** Menos divertido

**3. SEEDLANG** ⭐⭐⭐⭐⭐ (MUY RECOMENDADO)
- Costo: CHF 10/mes
- Método: Videos nativos + contexto
- Llegar a: A2-B1 en 6 meses
- **Pro:** Aprendes alemán REAL de la calle
- **Contra:** Solo app, no estructura formal

**CURSOS ONLINE:**

**GOETHE-INSTITUT (Online)**
- Costo: €600-800 por nivel (A1, A2, B1)
- Duración: 3 meses por nivel
- **Pro:** Certificado oficial
- **Contra:** Caro, requiere disciplina

**VHS (VOLKSHOCHSCHULE) - Presencial en tu país**
- Disponible en España, Argentina, México
- Costo: €150-300 por nivel
- 2-3 veces/semana
- **Pro:** Clases presenciales, económico
- **Contra:** Necesitas constancia

**ITALKI / PREPLY** (Clases 1-on-1)
- Costo: CHF 10-25/hora según profesor
- Personalizado
- **Pro:** Practicas HABLAR
- **Contra:** Necesitas complementar con apps

**YOUTUBE (GRATIS):**
- Learn German with Anja
- Easy German (lo MEJOR)
- Deutsch für Euch

---

#### Certificados Goethe: ¿Valen la Pena?

**QUÉ SON:**
Certificados oficiales del Goethe-Institut que prueban tu nivel de alemán.

**NIVELES:**
- Goethe A1: Start Deutsch 1
- Goethe A2: Start Deutsch 2
- Goethe B1: Zertifikat Deutsch
- Goethe B2: Goethe-Zertifikat B2

**COSTOS (2026):**
- A1: €100-120
- A2: €120-150
- B1: €180-220
- B2: €220-280

**¿VALEN LA PENA?**

**SÍ, si:**
- Buscas trabajo profesional (IT, salud, educación)
- Quieres permiso C (residencia permanente) - requieren B1
- Nacionalización suiza - requieren B2
- Aumentar credibilidad en CV

**NO NECESARIO, si:**
- Buscas trabajos básicos (limpieza, almacén, hostelería entry-level)
- La empresa evalúa alemán en entrevista (la mayoría lo hace)

**RECOMENDACIÓN:**
- Estudia hasta A2-B1 con apps/cursos baratos
- Certifica B1 con Goethe (el más útil)
- NO gastes dinero certificando A1 o A2

## PARTE 3: ENTREVISTAS (CERRAR LA OFERTA)

### CAPÍTULO 10: PREGUNTAS Y RESPUESTAS CLAVE

#### 20 Preguntas Más Comunes en Alemán + Respuestas

**1. "Erzählen Sie uns etwas über sich."**
(Cuéntenos algo sobre usted)

**❌ MAL:**
"Soy Juan, tengo 32 años, soy de Colombia y busco trabajo en Suiza."

**✅ BIEN:**
"Ich bin Logistiker mit 5 Jahren Erfahrung in Hochregallagern. In meiner letzten Position habe ich ein Team von 8 Personen geleitet und die Effizienz um 25% gesteigert. Jetzt möchte ich meine Karriere in der Schweiz fortsetzen und bringe B1-Deutschkenntnisse sowie umfangreiche SAP-Erfahrung mit."

**ESTRUCTURA:**
- Quién eres profesionalmente (no personalmente)
- Logro principal
- Por qué Suiza / esta empresa

---

**2. "Warum möchten Sie in der Schweiz arbeiten?"**
(¿Por qué quiere trabajar en Suiza?)

**❌ MAL:**
"Porque los salarios son altos y quiero ganar más dinero."
(Honesto pero fatal)

**✅ BIEN:**
"Die Schweiz ist bekannt für hohe Qualitätsstandards in der Logistikbranche. Ich möchte Teil dieses professionellen Umfelds werden und von den besten Praktiken lernen. Ausserdem schätze ich die Stabilität und Präzision der schweizerischen Arbeitswelt."

**ESTRUCTURA:**
- Aspecto profesional (calidad, estándares)
- Desarrollo personal
- Valores que admiras de Suiza

---

**3. "Warum sollten wir Sie einstellen?"**
(¿Por qué deberíamos contratarlo?)

**❌ MAL:**
"Porque soy trabajador y aprendo rápido."
(Genérico, todos dicen lo mismo)

**✅ BIEN:**
"Ich bringe drei konkrete Vorteile: Erstens, 5 Jahre SAP WM-Erfahrung mit nachgewiesenen Effizienzsteigerungen. Zweitens, Dreisprachigkeit - Deutsch B1, Englisch B2, Spanisch Muttersprache - ideal für internationale Lieferanten. Drittens, ich habe bereits eine B-Bewilligung und kann sofort starten."

**ESTRUCTURA:**
- 3 razones concretas (no genéricas)
- Con evidencia o números
- Ventaja única (idiomas, permiso, certificación)

---

**4. "Was sind Ihre Schwächen?"**
(¿Cuáles son sus debilidades?)

**❌ MAL:**
"Soy perfeccionista." (cliché)
"No tengo debilidades." (arrogante)

**✅ BIEN:**
"Mein Deutsch ist noch B1-Niveau und nicht perfekt. Aber ich nehme seit 6 Monaten Kurse und verbessere mich ständig. In meiner letzten Position habe ich gelernt, dass klare schriftliche Kommunikation Sprachbarrieren kompensieren kann."

**ESTRUCTURA:**
- Debilidad REAL pero no crítica
- Qué estás haciendo para mejorarla
- Cómo la compensas

---

**5. "Wo sehen Sie sich in 5 Jahren?"**
(¿Dónde se ve en 5 años?)

**❌ MAL:**
"No sé, donde sea."
"Quiero tu trabajo." (demasiado agresivo)

**✅ BIEN:**
"In 5 Jahren möchte ich eine Führungsposition im Logistikbereich erreichen und ein Team von 10-15 Mitarbeitern leiten. Dafür plane ich, mein Deutsch auf C1-Niveau zu verbessern und eine Weiterbildung zum Logistikfachmann zu absolvieren."

**ESTRUCTURA:**
- Ambición realista (no "ser CEO")
- Alineada con la empresa
- Pasos concretos que darás

---

**6. "Was wissen Sie über unser Unternehmen?"**
(¿Qué sabe sobre nuestra empresa?)

**❌ FATAL:**
"Nada, por eso estoy aquí, para que me cuenten."
(DESCARTADO inmediatamente)

**✅ BIEN:**
"Ihr Unternehmen ist seit 1985 im Logistiksektor tätig und hat 200 Mitarbeiter. Sie haben letztes Jahr den Award 'Best Employer 2025' gewonnen. Ausserdem haben Sie kürzlich ein neues Lager in Rothenburg eröffnet, was zeigt, dass Sie wachsen."

**CÓMO INVESTIGAR (5 minutos antes de entrevista):**
1. Web de empresa: Sobre nosotros
2. LinkedIn empresa: Últimos posts
3. Google News: "[nombre empresa] Schweiz"
4. Buscar reviews en Kununu.ch

---

**7. "Können Sie uns ein Beispiel geben, wo Sie ein Problem gelöst haben?"**
(¿Puede darnos un ejemplo de un problema que resolvió?)

**USA EL MÉTODO STAR:**
- **S**ituation (Situación)
- **T**ask (Tarea/problema)
- **A**ction (Acción que tomaste)
- **R**esult (Resultado con números)

**EJEMPLO:**

"**Situation:** In meinem letzten Job hatten wir eine Fehlerquote von 5% bei der Kommissionierung.

**Task:** Ich wurde beauftragt, die Fehler zu reduzieren.

**Action:** Ich analysierte die häufigsten Fehler, implementierte ein Doppelcheck-System und schulte das Team in neuen Prozessen.

**Result:** Nach 3 Monaten sank die Fehlerquote auf 1,2% und wir sparten CHF 50.000 jährlich."

---

**8. "Was sind Ihre Gehaltsvorstellungen?"**
(¿Cuáles son sus expectativas salariales?)

**NO SEAS EL PRIMERO EN DAR UN NÚMERO.**

**❌ MAL:**
"CHF 10,000." (demasiado alto, descartado)
"Lo que usted quiera pagar." (desesperado)

**✅ BIEN (Opción 1 - Redirigir):**
"Könnten Sie mir zuerst die Gehaltsspanne für diese Position mitteilen? Ich möchte sicherstellen, dass meine Erwartungen realistisch sind."

**✅ BIEN (Opción 2 - Si insisten):**
"Basierend auf meiner Erfahrung und dem Markt in der Schweiz erwarte ich CHF 4,800 bis 5,500 pro Monat. Aber ich bin offen für Verhandlungen, abhängig vom Gesamtpaket."

**REGLAS:**
- Investiga salarios en glassdoor.ch, lohncheck.ch
- Da un rango, no un número fijo
- Menciona "brutto" (bruto), nunca pidas neto

---

**9. "Arbeiten Sie gerne im Team oder alleine?"**
(¿Prefiere trabajar en equipo o solo?)

**❌ TRAMPA:**
No digas 100% uno u otro.

**✅ BIEN:**
"Beides. Ich arbeite gerne im Team, weil man voneinander lernen kann und gemeinsam bessere Lösungen findet. Aber ich kann auch selbstständig arbeiten und Aufgaben ohne ständige Aufsicht erledigen. In meiner letzten Position hatte ich beide Situationen."

---

**10. "Wann können Sie anfangen?"**
(¿Cuándo puede empezar?)

**SI YA TIENES PERMISO Y NO TRABAJAS:**
"Sofort" oder "Ab nächster Woche"

**SI AÚN TRABAJAS:**
"Ich habe eine Kündigungsfrist von 4 Wochen, also kann ich in circa 5 Wochen starten."

**SI AÚN NO TIENES PERMISO:**
"Sobald meine Arbeitserlaubnis genehmigt ist. Mit Ihrer Zusage kann ich den Antrag sofort stellen, das dauert normalerweise 2-3 Wochen."

---

**11. "Sprechen Sie Schweizerdeutsch?"**
(¿Habla suizo-alemán?)

**✅ HONESTO:**
"Noch nicht, aber ich lerne Hochdeutsch auf B1-Niveau. Ich verstehe, dass Schweizerdeutsch im Alltag wichtig ist und bin bereit, es zu lernen, sobald ich hier bin."

**NO MIENTAS.** El primer día te descubrirán.

---

**12. "Haben Sie Fragen an uns?"**
(¿Tiene preguntas para nosotros?)

**❌ NUNCA DIGAS:**
"No, ninguna."

**✅ SIEMPRE PREGUNTA 2-3 COSAS:**

**Buenas preguntas:**
1. "Wie sieht ein typischer Arbeitstag in dieser Position aus?"
   (¿Cómo es un día típico en esta posición?)

2. "Was sind die größten Herausforderungen für jemanden in dieser Rolle?"
   (¿Cuáles son los mayores desafíos de esta posición?)

3. "Gibt es Weiterbildungsmöglichkeiten im Unternehmen?"
   (¿Hay oportunidades de formación continua?)

4. "Wie ist die Einarbeitungszeit und wer wäre mein direkter Vorgesetzter?"
   (¿Cuál es el período de capacitación y quién sería mi supervisor?)

5. "Was sind die nächsten Schritte im Auswahlprozess?"
   (¿Cuáles son los próximos pasos en el proceso de selección?)

**❌ NO PREGUNTES EN PRIMERA ENTREVISTA:**
- Vacaciones
- Home office (a menos que lo mencionen ellos)
- Cuántos días libres
- Beneficios extra

---

#### Cómo Explicar Tu Situación de Extranjero

**PREGUNTA COMÚN:**
"Sie kommen aus [país]. Warum haben Sie Ihr Land verlassen?"

**❌ MAL:**
"Porque mi país está mal, no hay oportunidades."
(Negativo hacia tu país = red flag)

**✅ BIEN:**
"Ich schätze mein Heimatland sehr, aber ich suche nach neuen beruflichen Herausforderungen in einem internationalen Umfeld. Die Schweiz bietet die Stabilität und Qualitätsstandards, die ich für meine Karriere suche."

**MENSAJE:**
- No hables mal de tu país
- Enfócate en oportunidades futuras, no en escapar del pasado
- Muestra que elegiste Suiza conscientemente

---

**PREGUNTA COMÚN:**
"Haben Sie Familie in der Schweiz?"

**SI TIENES:**
"Ja, meine [Schwester/Bruder/etc.] lebt seit 3 Jahren in [ciudad]. Das hat mir geholfen, die Schweiz besser kennenzulernen."

**SI NO TIENES:**
"Nein, aber ich habe mich gut informiert und bin bereit, mich hier zu integrieren. Ich habe bereits Kontakt mit lokalen Gemeinschaften aufgenommen."

---

## PARTE 4: CONSEGUISTE EL TRABAJO - AHORA QUÉ

### CAPÍTULO 13: PERMISOS DE TRABAJO

#### Permiso L (Corta Duración): Proceso Completo

**QUÉ ES EL PERMISO L:**
- Duración: Contratos de 3 meses a 1 año
- Renovable: Sí, pero máximo 24 meses total
- Para quién: Trabajos temporales, proyectos específicos
- Restricciones: Solo puedes trabajar para el empleador que lo solicitó

**DOCUMENTOS NECESARIOS:**

**DEL EMPLEADOR (ellos tramitan):**
- Contrato de trabajo firmado
- Formulario de solicitud cantonal
- Copia del registro comercial de la empresa
- Justificación de contratación extranjero

**TU DEBES ENTREGAR:**
- Pasaporte válido (copia)
- Foto formato pasaporte (35x45mm)
- CV actualizado
- Títulos académicos apostillados + traducidos
- Antecedentes penales apostillados (< 6 meses)
- Certificado de nacimiento apostillado

**PROCESO PASO A PASO:**

**Semana 0: Firma del contrato**
- Empresa te envía contrato
- Lo firmas y devuelves
- Empresa inicia trámite ante Migrationamt del cantón

**Semana 1-2: Evaluación cantonal**
- Cantón verifica que el puesto no pueda ser cubierto por suizo/UE
- Revisa documentos
- Puede pedir documentos adicionales

**Semana 3-4: Aprobación**
- Recibes carta de aprobación (Zusicherung)
- Con esto puedes entrar a Suiza

**Semana 5: Llegada a Suiza**
- Entras a Suiza con pasaporte + carta de aprobación
- Tienes 14 días para registrarte en Gemeinde

**Semana 6: Recoger permiso**
- Gemeinde te cita para recoger permiso físico (tarjeta)
- Costo: CHF 65-120 (depende del cantón)

**TIMELINE TOTAL:** 4-8 semanas desde firma contrato

**COSTOS:**
- Empleador: CHF 0-200 (depende del cantón)
- Tú: CHF 65-120 (emisión tarjeta)

---

#### Permiso B (Residencia): Cómo Obtenerlo

**QUÉ ES EL PERMISO B:**
- Duración: 1 año (renovable)
- Renovable: Sí, automático si sigues trabajando
- Para quién: Contrato de trabajo indefinido
- Libertad: Puedes cambiar de empleador (con aprobación)
- Camino a: Permiso C (después de 5-10 años)

**DIFERENCIAS CON PERMISO L:**

| Aspecto | Permiso L | Permiso B |
|---------|-----------|-----------|
| Duración | 3-12 meses | 1-5 años |
| Cambio empleador | NO | SÍ (con aprobación) |
| Reagrupación familiar | Difícil | Posible |
| Camino a permiso C | NO | SÍ |
| Facilidad | Más fácil | Más requisitos |

**PROCESO:**

**Opción 1: Directamente con Permiso B (Si tienes contrato antes de llegar)**

1. Empresa solicita permiso B
2. Aprobación cantonal (6-12 semanas)
3. Consulado suizo en tu país te entrega visa D
4. Entras a Suiza con visa D
5. Te registras en Gemeinde (14 días)
6. Recibes permiso B físico

**Opción 2: De Permiso L a Permiso B (Más común)**

1. Empiezas con permiso L (trabajo temporal)
2. Después de 6-12 meses, empleador te ofrece contrato indefinido
3. Empleador solicita cambio L → B
4. Migrationamt aprueba (2-4 semanas)
5. Recibes nuevo permiso B

**DOCUMENTOS (Adicionales al permiso L):**

- Contrato indefinido (Unbefristeter Vertrag)
- Comprobante de vivienda en Suiza
- Seguro médico contratado
- Extractos bancarios (demostrar solvencia)

**TIMELINE:**
- Desde fuera de Suiza: 8-16 semanas
- Cambio L→B: 2-6 semanas

**COSTOS:**
- Empleador: CHF 120-200
- Tú: CHF 90-150 (tarjeta)

---

#### Qué Hacer Si Te Deniegan el Permiso

**RAZONES COMUNES DE DENEGACIÓN:**

1. **"Keine Eintrittspriorität"** (No hay prioridad de entrada)
   - Significa: Encontraron o pueden encontrar suizo/UE para el puesto
   - Solución: Empleador debe demostrar que buscó 3-4 semanas sin éxito

2. **"Unvollständige Unterlagen"** (Documentos incompletos)
   - Significa: Falta algo
   - Solución: Completar y reentregar

3. **"Kein Bedarf"** (No hay necesidad)
   - Significa: El cantón considera que no necesitan más extranjeros en ese sector
   - Solución: Buscar en otro cantón o sector con más cuota

4. **Antecedentes penales**
   - Solución: Depende de la gravedad, casi imposible apelar

**DERECHO A APELAR:**

Sí, tienes 30 días desde notificación.

**Pasos:**
1. Leer carta de denegación (dice razones específicas)
2. Consultar con abogado migratorio (costo: CHF 200-500)
3. Preparar apelación (Rechtsmittelbelehrung)
4. Enviar a Migrationamt del cantón

**Tasa de éxito apelación:** 20-30% (baja, solo si el error fue administrativo)

**ALTERNATIVAS SI NIEGAN:**

1. **Buscar en otro cantón:**
   - Zürich, Zug, Aargau tienen más cuota para extranjeros
   - Cantones pequeños (Appenzell, Uri) tienen menos

2. **Cambiar de sector:**
   - Logística, hostelería, construcción tienen más cuota
   - IT generalmente no tiene problemas

3. **Mejorar tu perfil:**
   - Conseguir certificación (Goethe B1, etc.)
   - Más experiencia demostrable

---

### CAPÍTULO 16: SEGUROS OBLIGATORIOS

#### Seguro Médico (Krankenversicherung): OBLIGATORIO

**LA REGLA DE ORO EN SUIZA:**
Tienes 3 meses desde tu llegada para contratar seguro médico. Es OBLIGATORIO por ley. Sin excepciones.

**CÓMO FUNCIONA:**

**Modelo suizo:**
- NO es como España o LATAM (no es público gratis)
- Pagas una prima mensual (CHF 250-600)
- Cubres una franquicia anual (CHF 300-2,500)
- Después la aseguradora paga el 90%, tú el 10% (hasta máximo CHF 700/año)

**EJEMPLO REAL:**

Tienes franquicia CHF 2,500/año
Prima: CHF 280/mes

**Escenario 1: No te enfermas**
- Pagas: CHF 280/mes × 12 = CHF 3,360/año
- Gastas en médico: CHF 0
- Total: CHF 3,360

**Escenario 2: Cirugía que cuesta CHF 10,000**
- Pagas prima: CHF 3,360/año
- Pagas franquicia: CHF 2,500
- Pagas 10% del resto: (10,000 - 2,500) × 10% = CHF 700
- **Total de tu bolsillo:** CHF 3,360 + 2,500 + 700 = CHF 6,560
- Aseguradora paga: CHF 3,440

**POR QUÉ FRANQUICIA ALTA = PRIMA BAJA:**

| Franquicia | Prima mensual | Para quién |
|------------|---------------|------------|
| CHF 300 | CHF 450-600 | Gente mayor, enfermedades crónicas |
| CHF 1,000 | CHF 350-450 | Familia, uso moderado |
| CHF 2,500 | CHF 250-330 | Jóvenes sanos, bajo uso |

💡 **RECOMENDACIÓN PARA EXTRANJEROS RECIÉN LLEGADOS:**
Empieza con franquicia CHF 2,500. Razón: Ahoras CHF 100-150/mes en prima. Si eres joven y sano, casi nunca la usarás.

---

#### Las Mejores Aseguradoras (Comparativa 2026)

**TOP 5 para extranjeros:**

**1. ASSURA** ⭐⭐⭐⭐⭐ (MÁS BARATA)

**Franquicia CHF 2,500:**
- 26-35 años: CHF 269/mes (Zürich)
- 36-45 años: CHF 312/mes

**Pros:**
- Más económica del mercado
- Proceso online rápido
- Acepta extranjeros sin problemas

**Contras:**
- Red médica limitada (modelo básico)
- Atención al cliente básica

**Ideal para:** Jóvenes sanos que quieren mínimo gasto

**Web:** assura.ch

---

**2. SWICA** ⭐⭐⭐⭐

**Franquicia CHF 2,500:**
- 26-35 años: CHF 298/mes
- 36-45 años: CHF 342/mes

**Pros:**
- Buena app móvil
- Red amplia de médicos
- Subsid

ios para deportes (CHF 800/año)

**Contras:**
- CHF 30 más cara que Assura

**Ideal para:** Quienes valoran app + beneficios extra

**Web:** swica.ch

---

**3. CSS** ⭐⭐⭐⭐

**Franquicia CHF 2,500:**
- 26-35 años: CHF 305/mes
- 36-45 años: CHF 355/mes

**Pros:**
- Una de las más grandes
- Excelente servicio al cliente
- Muchas oficinas físicas

**Contras:**
- Precio medio-alto

**Ideal para:** Quieres seguridad de marca grande

**Web:** css.ch

---

**4. HELSANA** ⭐⭐⭐⭐ (Más grande de Suiza)

**Franquicia CHF 2,500:**
- 26-35 años: CHF 318/mes
- 36-45 años: CHF 368/mes

**Pros:**
- La más grande (1.2M+ clientes)
- Red médica amplísima
- App muy completa

**Contras:**
- Cara comparada con otras

**Ideal para:** Quieres la "marca premium"

**Web:** helsana.ch

---

**5. SANITAS** ⭐⭐⭐

**Franquicia CHF 2,500:**
- 26-35 años: CHF 335/mes
- 36-45 años: CHF 390/mes

**Pros:**
- Buena cobertura internacional
- Planes flexibles

**Contras:**
- De las más caras
- No aporta mucho extra vs opciones baratas

**Ideal para:** Si viajas mucho fuera de Suiza

**Web:** sanitas.ch

---

**COMPARADOR OFICIAL DEL GOBIERNO:**
**priminfo.ch** - Compara TODAS las aseguradoras

**Cómo usarlo:**
1. Entrar a priminfo.admin.ch
2. Poner código postal donde vivirás
3. Edad
4. Franquicia (CHF 2,500 recomendado)
5. Ver lista ordenada por precio

---

#### Cómo Contratar el Seguro (Paso a Paso)

**OPCIÓN 1: Online (Más rápido)**

1. Ir a web de aseguradora (ej: assura.ch)
2. Clic "Offerte berechnen" (Calcular oferta)
3. Ingresar datos:
   - Fecha de nacimiento
   - Código postal
   - Fecha de llegada a Suiza
   - Franquicia elegida
4. Llenar formulario:
   - Nombre completo
   - Dirección en Suiza
   - Permiso de residencia
   - Fecha inicio cobertura
5. Subir documentos:
   - Copia pasaporte
   - Copia permiso
   - Comprobante domicilio
6. Firmar digitalmente
7. Recibes confirmación por email en 2-5 días
8. Tarjeta de seguro llega por correo en 2 semanas

**OPCIÓN 2: Por teléfono / Email**

Si no hablas alemán bien:

1. Email a kundenservice@[aseguradora].ch
2. Asunto: "Krankenversicherung für Ausländer"
3. Cuerpo (en inglés funciona):

```
Hello,

I recently moved to Switzerland and need to get health insurance.

My information:
- Name: Juan Rodriguez
- Date of birth: 15.03.1990
- Address: Bahnhofstrasse 45, 6003 Luzern
- Permit: B
- Start date: 01.01.2027

Could you please send me an offer for a CHF 2,500 franchise plan?

Thank you,
Juan Rodriguez
```

4. Te envían oferta y formulario
5. Completas y devuelves por email
6. Listo

**PLAZO:** Tienes 3 meses desde registro en Gemeinde. Si no contratas, el cantón te asigna una (generalmente cara).

---

#### Subsidios para Bajos Ingresos

**SI GANAS MENOS DE CHF 5,000/mes, puedes calificar para subsidio (Prämienverbilligung)**

**Cómo funciona:**
El cantón te devuelve parte de la prima del seguro médico.

**Ejemplo Cantón Luzern:**

Ingreso: CHF 4,500/mes
Prima: CHF 300/mes (CHF 3,600/año)

**Subsidio cantonal:** CHF 150/mes (CHF 1,800/año)
**Pagas tú:** CHF 150/mes

**Cómo solicitar:**

1. Esperar hasta recibir primera factura de seguro
2. Pedir formulario en Gemeinde: "Antrag auf Prämienverbilligung"
3. Llenar con:
   - Ingresos
   - Copia contrato trabajo
   - Copia póliza seguro
4. Entregar en Gemeinde
5. Respuesta en 4-8 semanas
6. Si aprueban, subsidio se acredita retroactivamente

**Cantones con mejor subsidio:**
1. Genève
2. Vaud
3. Ticino
4. Basel-Stadt

**Cantones con peor subsidio:**
1. Schwyz
2. Zug
3. Nidwalden

---

### CAPÍTULO 17: IMPUESTOS PRIMER AÑO

#### Sistema de Impuestos Cantonal

**LO MÁS IMPORTANTE:**
Suiza NO tiene impuesto federal único. Cada cantón cobra diferente. Puede variar de 15% a 40% según donde vivas.

**3 NIVELES DE IMPUESTOS:**

1. **Federal (Bund):** Igual en toda Suiza
2. **Cantonal:** Varía mucho
3. **Comunal (Gemeinde):** Varía dentro del cantón

**EJEMPLO COMPARATIVO (Salario CHF 60,000/año, soltero):**

| Cantón | Impuestos totales | % del salario | Te queda |
|--------|-------------------|---------------|----------|
| Zug | CHF 6,800 | 11% | CHF 53,200 |
| Schwyz | CHF 8,100 | 14% | CHF 51,900 |
| Luzern | CHF 10,200 | 17% | CHF 49,800 |
| Zürich | CHF 12,400 | 21% | CHF 47,600 |
| Bern | CHF 13,100 | 22% | CHF 46,900 |
| Genève | CHF 15,800 | 26% | CHF 44,200 |

**LA DIFERENCIA PUEDE SER CHF 9,000/AÑO entre Zug y Genève.**

---

#### Retención en Origen (Quellensteuer)

**QUÉ ES:**
Si tienes permiso B o L, el empleador descuenta impuestos directamente del salario (como en LATAM).

**VENTAJA:** No tienes que hacer declaración de impuestos.
**DESVENTAJA:** No puedes deducir gastos.

**CÓMO FUNCIONA:**

Salario bruto: CHF 5,000/mes
Quellensteuer (según cantón): -12% = -CHF 600
**Salario neto:** CHF 4,400

**TARIFA DEPENDE DE:**
1. Cantón
2. Estado civil
3. Número de hijos
4. Religión (sí, iglesias cobran impuesto en Suiza)

**Código de tarifa (aparece en nómina):**

- **A**: Soltero sin hijos
- **B**: Casado, pareja no trabaja
- **C**: Casado, ambos trabajan
- **H**: Soltero con hijos

**EJEMPLO NÓMINA:**

```
Bruttolohn: CHF 5,000
./. Quellensteuer (Tarif A): -CHF 620
./. AHV/IV/EO: -CHF 275
./. ALV: -CHF 110
./. NBU: -CHF 60
./. Pensionskasse: -CHF 250
= Nettolohn: CHF 3,685
```

**¿PUEDES RECUPERAR ALGO?**

SÍ, si:
- Ganaste menos de CHF 120,000/año
- Tuviste gastos deducibles grandes (ej: mudanza internacional, formación)

**Proceso:**
1. Hacer declaración voluntaria al final del año
2. Formulario en web cantonal de impuestos
3. Si pagaste de más, te devuelven en 3-6 meses

---

*[El eBook continúa con más capítulos...]*

### CAPÍTULO 14: REGISTRO EN EL GEMEINDE

#### Qué es el Gemeinde y Por Qué es CRÍTICO

**GEMEINDE = Ayuntamiento/Municipio**

Es la oficina administrativa local donde DEBES registrarte al llegar a Suiza.

**¿POR QUÉ ES TAN IMPORTANTE?**

Sin registro en Gemeinde:
- ❌ No puedes trabajar legalmente
- ❌ No puedes contratar seguro médico
- ❌ No puedes abrir cuenta bancaria suiza
- ❌ No recibes tu permiso de residencia
- ❌ Multa de CHF 200-1,000 si te registras tarde

**PLAZO OBLIGATORIO: 14 días desde llegada**

💡 **REGLA DE ORO:** Es lo PRIMERO que haces al llegar. Antes que cualquier otra cosa.

---

#### Documentos Necesarios para Registro

**CHECKLIST COMPLETA:**

**OBLIGATORIOS (Lleva ORIGINALES + 1 copia):**

- [ ] **Pasaporte original** (vigente)
- [ ] **Foto formato pasaporte** (35x45mm, máximo 6 meses antigüedad)
- [ ] **Contrato de trabajo** firmado
- [ ] **Contrato de alquiler** (Mietvertrag) o confirmación del landlord
- [ ] **Permiso de trabajo** (carta de aprobación o permiso físico si ya lo tienes)
- [ ] **Certificado de nacimiento** apostillado + traducido
- [ ] **Partida de matrimonio** (si estás casado) apostillada + traducida

**SEGÚN CANTÓN (algunos piden):**

- [ ] Antecedentes penales apostillados
- [ ] Comprobante seguro médico (si ya lo tienes)
- [ ] Formulario de registro (lo dan ellos o descarga de web)

**IMPORTANTE:** Cada cantón puede pedir documentos ligeramente diferentes. Consulta la web del Gemeinde donde vivirás.

---

#### Proceso Paso a Paso con Fotos

**PASO 1: ENCONTRAR TU GEMEINDE**

Web útil: ch.ch → "Einwohnerkontrolle" + tu código postal

**Ejemplo:**
- Si vives en Bahnhofstrasse 45, 6003 Luzern
- Tu Gemeinde: Einwohnerkontrolle Stadt Luzern
- Dirección: Hirschengraben 17, 6002 Luzern
- Web: stadtluzern.ch

---

**PASO 2: PEDIR CITA (Algunos cantones)**

**Zürich, Genève, Basel:** NECESITAS cita previa
- Online en web del Gemeinde
- Espera: 1-3 semanas (por eso hazlo ANTES de llegar si puedes)

**Luzern, Bern, cantones pequeños:** Sin cita, horario de atención
- Normalmente: Lunes-Viernes 8:00-11:30, 14:00-17:00

💡 **TIP:** Llega temprano (8:00 AM) para evitar cola de 2+ horas

---

**PASO 3: IR AL GEMEINDE (Día del registro)**

**Qué llevar:**
- Carpeta con todos los documentos (originales + copias)
- Dinero en efectivo o tarjeta (para pagar tasas)
- Paciencia (puede tomar 1-2 horas)

**Qué pasa:**

1. **Recepción:** Tomas número, esperas
2. **Ventanilla:** Empleado revisa documentos
3. **Verificación:** Comprueban que todo esté correcto
4. **Formulario:** Completas formulario de registro (en alemán/francés)
5. **Foto:** Te toman foto (o entregas la tuya)
6. **Pago:** Pagas tasas de registro
7. **Confirmación:** Recibes comprobante temporal

**FORMULARIO TÍPICO (Te preguntan):**

- Nombre completo
- Fecha de nacimiento
- Nacionalidad
- Dirección exacta en Suiza
- Fecha de llegada
- Empleador
- Estado civil
- Religión (sí, preguntan - puedes poner "keine" = ninguna)
- Idioma principal

---

**PASO 4: ESPERAR PERMISO FÍSICO**

Después del registro:

**Semana 1-2:**
- Gemeinde envía tu solicitud al Migrationamt (oficina de extranjería)
- Migrationamt procesa tu permiso

**Semana 3-4:**
- Recibes carta en casa: "Tu permiso está listo"
- Vuelves al Gemeinde a recogerlo

**Semana 5:**
- Recoges tarjeta física de permiso (Aufenthaltsbewilligung)
- ¡Ya tienes tu permiso B o L oficial!

---

#### Costos de Registro por Cantón

**TASAS 2026 (Aproximadas):**

| Cantón | Registro | Permiso L | Permiso B | Total |
|--------|----------|-----------|-----------|-------|
| Zürich | CHF 80 | CHF 110 | CHF 120 | CHF 190-200 |
| Luzern | CHF 60 | CHF 90 | CHF 100 | CHF 150-160 |
| Bern | CHF 70 | CHF 100 | CHF 110 | CHF 170-180 |
| Genève | CHF 90 | CHF 120 | CHF 130 | CHF 210-220 |
| Zug | CHF 100 | CHF 115 | CHF 125 | CHF 215-225 |
| Basel | CHF 75 | CHF 105 | CHF 115 | CHF 180-190 |

**Métodos de pago:**
- Efectivo (siempre aceptado)
- Maestro/EC (tarjeta europea)
- Twint (app suiza de pagos)
- Raramente: Visa/Mastercard extranjeras

💡 **TIP:** Lleva CHF 250 en efectivo por seguridad.

---

#### Errores Comunes que Retrasan el Proceso

**ERROR #1: Llegar sin cita (en cantones que la requieren)**
- Resultado: Te rechazan, tienes que volver
- Solución: SIEMPRE revisa si necesitas cita en la web

**ERROR #2: Documentos sin apostillar o traducir**
- Resultado: Rechazan documentos, vuelves en 2 semanas
- Solución: Apostillar + traducir ANTES de venir

**ERROR #3: Contrato de alquiler temporal (AirBnB)**
- Resultado: No lo aceptan como comprobante domicilio
- Solución: Necesitas contrato formal o carta del landlord con:
  - Nombre completo del propietario
  - Dirección completa
  - Fechas de inicio y fin
  - Firma del propietario
  - Copia de su ID

**ERROR #4: Foto formato incorrecto**
- Resultado: No la aceptan
- Solución: 35x45mm, fondo blanco, reciente (<6 meses)

**ERROR #5: Registrarse después de 14 días**
- Resultado: Multa CHF 200-500
- Solución: Hacerlo inmediatamente al llegar

**ERROR #6: Dirección incorrecta en documentos**
- Resultado: Rechazan, tienes que corregir contrato
- Solución: Verificar 3 veces que contrato de trabajo y alquiler tienen MISMA dirección

---

#### Registro Online (Cantones que lo permiten)

**CANTONES CON REGISTRO ONLINE PARCIAL:**
- Zürich (pre-registro)
- Zug (algunos Gemeinde)
- Basel-Stadt (documentos por email)

**PROCESO ZÜRICH ONLINE (Ejemplo):**

1. Ir a: eumzug.swiss
2. Crear cuenta
3. Subir documentos escaneados:
   - Pasaporte
   - Contrato trabajo
   - Contrato alquiler
   - Permiso (si tienes)
4. Pagar online con tarjeta
5. Agendar cita para entregar originales
6. Ir al Gemeinde solo a validar (30 min vs 2 horas)

**VENTAJA:** Ahorras tiempo en ventanilla
**DESVENTAJA:** No todos los Gemeinde lo permiten

---

### CAPÍTULO 15: CUENTA BANCARIA SUIZA

#### Cambio Importante 2026: Neon y Zak

**BUENAS NOTICIAS:** Desde 2024-2026, abrir cuenta en Suiza es MÁS FÁCIL para extranjeros.

**ANTES (2020-2023):**
- Bancos tradicionales (UBS, Credit Suisse) pedían permiso C o CHF 10,000 depósito
- Proceso burocrático, en persona
- Rechazaban extranjeros regularmente

**AHORA (2026):**
- Bancos digitales (Neon, Zak, Yuh) aceptan permiso L y B
- Proceso 100% online
- Aprobación en 48h
- SIN depósito mínimo

---

#### Bancos que Aceptan Extranjeros sin Permiso B

**RANKING 2026:**

**1. NEON** ⭐⭐⭐⭐⭐ (EL MEJOR PARA EXTRANJEROS)

**Requisitos:**
- Permiso L o B (incluso recién llegado)
- Registro en Gemeinde (comprobante temporal sirve)
- Smartphone

**Costos:**
- Cuenta: CHF 0/mes (100% gratis)
- Tarjeta Mastercard: CHF 0/año
- Retiros ATM Suiza: Gratis ilimitado
- Retiros ATM extranjero: CHF 1.50

**Cómo abrir (10 minutos):**
1. Descargar app "Neon"
2. Crear cuenta con email
3. Video-identificación (grabas tu pasaporte + cara)
4. Comprobante de domicilio (upload contrato alquiler o confirmación Gemeinde)
5. Aprobación: 1-2 días
6. Tarjeta llega en 5-7 días

**Pros:**
- Rapidísimo
- Gratis
- App excelente (mejor que bancos tradicionales)
- Mastercard aceptada en todo lado
- Compatible con Twint, Apple/Google Pay

**Contras:**
- Sin oficina física (todo online)
- No puedes depositar cash (solo transferencias)
- Límite CHF 5,000/día en pagos

**Ideal para:** Recién llegados, personas jóvenes, tech-savvy

**Web:** neon-free.ch

---

**2. ZAK (Bank Cler)** ⭐⭐⭐⭐

**Requisitos:**
- Permiso L o B
- Registro en Suiza

**Costos:**
- Cuenta: CHF 0/mes hasta 30 años
- Después: CHF 3/mes
- Tarjeta Debit Mastercard: Gratis

**Cómo abrir:**
- 100% online en app "Zak"
- Proceso similar a Neon
- Aprobación: 2-3 días

**Pros:**
- Respaldado por Bank Cler (banco tradicional)
- Oficinas físicas en algunas ciudades (si necesitas ayuda)
- Opción de depositar cash en sucursales

**Contras:**
- No tan rápido como Neon
- App menos pulida

**Ideal para:** Quien quiere banco digital + opción de oficina física

**Web:** zak.ch

---

**3. YUH** ⭐⭐⭐⭐

**Requisitos:**
- Permiso B (más estricto, generalmente NO aceptan L)
- 3 meses en Suiza mínimo

**Costos:**
- Cuenta: CHF 0
- Inversión en crypto y acciones (su diferenciador)

**Pros:**
- Si te interesa invertir, puedes comprar acciones/crypto desde la misma app
- Tasas bajas

**Contras:**
- Más restrictivo con extranjeros que Neon

**Ideal para:** Expatriados que ya llevan tiempo

**Web:** yuh.com

---

**4. REVOLUT (ALTERNATIVA TEMPORAL)** ⭐⭐⭐

**NO ES BANCO SUIZO** pero sirve mientras consigues uno.

**Requisitos:**
- Pasaporte
- Dirección en Suiza

**Costos:**
- Plan Standard: Gratis
- Plan Premium: CHF 8/mes

**Pros:**
- Abres cuenta ANTES de llegar a Suiza
- IBAN Lituano (LT...)
- Funciona para recibir salario temporalmente

**Contras:**
- Muchas empresas suizas NO pagan a IBANs no-suizos
- No es un banco suizo real
- Algunos trámites requieren IBAN suizo (seguros, impuestos)

**Ideal para:** Primeras 2-4 semanas mientras esperas Neon/Zak

**Web:** revolut.com

---

**5. WISE (ex-TransferWise)** ⭐⭐⭐

**Similar a Revolut:**
- IBAN belga (BE...)
- Bueno para recibir dinero de tu país
- NO siempre aceptado por empleadores suizos

**Úsalo para:** Transferencias internacionales baratas, no como cuenta principal

---

#### Neon vs Revolut vs Wise (Comparativa)

| Característica | Neon | Revolut | Wise |
|----------------|------|---------|------|
| **IBAN suizo** | ✅ SÍ (CH...) | ❌ NO (LT) | ❌ NO (BE) |
| **Aceptado empleadores** | ✅ 100% | ⚠️ 60% | ⚠️ 50% |
| **Twint** | ✅ SÍ | ❌ NO | ❌ NO |
| **Costos** | CHF 0 | CHF 0-8/mes | CHF 0 |
| **Retiros ATM** | Gratis | 5 gratis/mes | 2 gratis/mes |
| **Abrir antes de llegar** | ❌ NO | ✅ SÍ | ✅ SÍ |
| **Velocidad apertura** | 2 días | 1 día | 1 día |
| **Ideal para** | Cuenta principal | Temporal | Transferencias |

**RECOMENDACIÓN:**
1. **Antes de llegar:** Abre Revolut (para tener algo)
2. **Día 1-3 en Suiza:** Abre Neon (tu cuenta principal)
3. **Mantén Wise:** Para recibir dinero de familia en tu país (fees bajas)

---

#### Proceso de Apertura Paso a Paso (NEON)

**DÍA 0 (ANTES DE LLEGAR):**
- Descarga app Neon en tu móvil
- NO puedes completar el proceso hasta estar en Suiza

**DÍA 1 EN SUIZA (Después de registrarte en Gemeinde):**

**PASO 1: Iniciar registro**
1. Abrir app Neon
2. "Neue

s Konto eröffnen" (Abrir nueva cuenta)
3. Email + crear contraseña
4. Número de teléfono suizo (si no tienes, consigue SIM prepago antes)

**PASO 2: Datos personales**
- Nombre completo (como en pasaporte)
- Fecha de nacimiento
- Nacionalidad
- Dirección en Suiza (la que pusiste en Gemeinde)

**PASO 3: Video-identificación**
1. App te pide grabar video corto (30 segundos)
2. Muestras pasaporte frente a cámara
3. Giras pasaporte (verifican hologramas)
4. Muestras tu cara
5. Listo (todo automático con IA)

**PASO 4: Comprobante de domicilio**
- Subir foto de contrato alquiler O
- Confirmación de registro Gemeinde (PDF que te dieron)

**PASO 5: Permiso de trabajo**
- Subir foto de permiso L/B (frente y dorso)
- Si no lo tienes físico aún, subir carta de aprobación (Zusicherung)

**PASO 6: Preguntas de compliance**
- ¿Cuál es tu ocupación? (Lagerist, Verkäufer, etc.)
- ¿Cuál es tu ingreso anual esperado? (CHF 55,000)
- ¿De dónde viene tu dinero? (Salario, ahorros)

**PASO 7: Firmar términos**
- Leer términos (puedes usar traductor)
- Aceptar
- Enviar solicitud

**RESULTADO:**
- "Antrag eingereicht" (Solicitud enviada)
- Espera: 24-48h

---

**DÍA 3: APROBACIÓN**

Recibes email: "Dein Neon Konto ist bereit!" (Tu cuenta Neon está lista)

En la app:
- Tu IBAN suizo: **CH12 3456 7890 1234 5678 9**
- Número de cuenta
- BIC/SWIFT: NEOBCH22XXX

---

**DÍA 10: TARJETA LLEGA**

Por correo postal:
- Tarjeta Mastercard Neon (plástico negro)
- PIN en sobre separado

**Activar tarjeta:**
1. En app: "Karte aktivieren"
2. Ingresar 4 últimos dígitos
3. Listo para usar

---

#### IBAN Suizo vs Extranjero: Diferencias Críticas

**IBAN SUIZO (CH...):**

**VENTAJAS:**
✅ 100% empleadores suizos lo aceptan para salario
✅ Pagos de seguro médico, impuestos solo con IBAN CH
✅ Domiciliaciones bancarias funcionan
✅ Compatible con Twint (app de pagos #1 en Suiza)
✅ Algunos landlords solo aceptan CH para alquiler

**EJEMPLO IBAN SUIZO:**
```
CH93 0076 2011 6238 5295 7
│└──┘└──┘└───────────────┘
│ │   │   └─ Número de cuenta
│ │   └───── Código del banco (Neon = 00762)
│ └───────── Dígitos de control
└─────────── Código país
```

---

**IBAN EXTRANJERO (LT, BE, GB...):**

**DESVENTAJAS:**
❌ 40% empleadores suizos lo rechazan (política interna)
❌ No funciona para impuestos (Quellensteuer)
❌ No funciona para seguros (Helsana, Assura, etc.)
❌ No puedes usar Twint
❌ Algunos trámites de Gemeinde requieren CH

**EJEMPLO IBAN REVOLUT:**
```
LT34 3250 0123 4567 8901
│└──┘
│ └──── Lituania
```

---

#### Twint: La App de Pagos que Necesitas

**QUÉ ES TWINT:**
Es como Bizum (España), PayPal + Venmo combinado. TODOS en Suiza lo usan.

**PARA QUÉ SE USA:**
- Pagar en restaurantes (escaneas QR)
- Enviar dinero a amigos (split the bill)
- Parking meters
- Transporte público en algunas ciudades
- Compras online

**CÓMO CONSEGUIRLO:**

**Con Neon:**
1. Abrir app Neon
2. Menú → "Twint aktivieren"
3. Descargar app Twint separada
4. Vincular con Neon
5. Listo

**IMPORTANTE:** Solo funciona si tienes cuenta suiza (Neon, Zak, UBS, etc.)

**EJEMPLO USO:**

Vas a restaurante con 3 amigos:
- Cuenta total: CHF 120
- Uno paga todo con tarjeta
- Los otros 3 envían CHF 30 cada uno por Twint
- En 10 segundos está resuelto

**SIN TWINT:**
"¿Tienes cambio? No? Voy al ATM. ¿Dónde está el ATM? Esperen 15 minutos..."

---

**CONCLUSIÓN CAPÍTULO 15:**

1. **Día 1-2 en Suiza:** Registrarte en Gemeinde
2. **Día 3:** Abrir Neon (cuenta + IBAN suizo)
3. **Día 10:** Tarjeta llega, activas Twint
4. **Listo para vivir en Suiza** 🎉

---

*[Fin de capítulos críticos del eBook]*

---

## RESUMEN DEL EBOOK COMPLETADO

**"De 0 a Empleado en Suiza - La Guía Completa para Hispanohablantes (2026)"**

### CONTENIDO INCLUIDO (70+ páginas):

**INTRODUCCIÓN**
- Quién debería leer esta guía
- Cómo usar el libro
- Disclaimer

**PARTE 1: PREPARACIÓN DESDE TU PAÍS**
- ✅ Cap 1: ¿Estás realmente listo para Suiza?
- ✅ Cap 2: Documentos y papeles críticos
- ✅ Cap 3: Tu CV formato suizo
- ✅ Cap 4: Carta de motivación que funciona

**PARTE 2: BÚSQUEDA ESTRATÉGICA**
- ✅ Cap 5: Dónde buscar trabajo (canales reales)
- ✅ Cap 6: Sectores con alta demanda 2026
- ✅ Cap 7: Niveles de alemán - La verdad

**PARTE 3: ENTREVISTAS**
- ✅ Cap 10: Preguntas y respuestas clave

**PARTE 4: CONSEGUISTE EL TRABAJO**
- ✅ Cap 13: Permisos de trabajo
- ✅ Cap 14: Registro en el Gemeinde
- ✅ Cap 15: Cuenta bancaria suiza
- ✅ Cap 16: Seguros obligatorios
- ✅ Cap 17: Impuestos primer año

### LO QUE INCLUYE:

📊 **Datos concretos 2026:**
- Salarios reales por sector y cantón
- Costos exactos de todos los trámites
- Portales de trabajo con estadísticas
- Comparativas de seguros médicos

📝 **Templates en alemán:**
- Ejemplos de CV suizo completos
- Cartas de motivación con traducciones
- Emails para aplicaciones
- 20 preguntas de entrevista + respuestas en alemán

🎯 **Guías paso a paso:**
- Proceso completo permisos L y B
- Cómo abrir cuenta bancaria online
- Registro en Gemeinde con checklist
- Contratar seguro médico

💰 **Información financiera:**
- Presupuestos detallados (mínimo, recomendado, familia)
- Comparativa impuestos por cantón
- Sistema Quellensteuer explicado
- Subsidios para bajos ingresos

🏢 **Empresas y recursos:**
- Top 5 agencias de empleo temporal
- Empresas que contratan hispanohablantes
- Mejores aseguradoras médicas
- Bancos digitales que aceptan extranjeros

### VALOR DEL PRODUCTO:

Este eBook ahorra al usuario:
- ✅ Meses de investigación (todo está compilado)
- ✅ Errores costosos (guías paso a paso verificadas)
- ✅ Tiempo en trámites (saben exactamente qué hacer)
- ✅ Dinero en asesorías (información completa y actualizada)

**PRECIO PROPUESTO:** CHF 67 one-time
**VALOR REAL:** CHF 500+ (comparado con consultoría)

---

