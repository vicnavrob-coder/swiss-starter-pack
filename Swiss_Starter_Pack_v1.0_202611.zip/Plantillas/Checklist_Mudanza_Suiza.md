# ✈️ CHECKLIST COMPLETA: MUDANZA A SUIZA
## Guía paso a paso - De 0 a instalado

---

## 📅 3 MESES ANTES DE LA MUDANZA

### Investigación y Planificación
- [ ] Definir cantón/ciudad destino (investigar costos de vida, impuestos)
- [ ] Investigar salarios promedio en tu sector
- [ ] Calcular presupuesto inicial necesario (mínimo CHF 5,000-10,000)
- [ ] Empezar curso de alemán (objetivo: A1-A2 antes de llegar)
- [ ] Unirse a grupos de Facebook/Telegram de hispanohablantes en Suiza

### Búsqueda de Trabajo
- [ ] Crear CV formato suizo en alemán
- [ ] Crear perfil LinkedIn en alemán
- [ ] Registrarse en jobs.ch, indeed.ch, jobscout24.ch
- [ ] Configurar alertas de empleo por email
- [ ] Contactar agencias de empleo temporal (Adecco, Randstad, Manpower)
- [ ] Enviar 20-30 aplicaciones

### Documentos Oficiales
- [ ] Renovar pasaporte (mínimo 2 años de validez)
- [ ] Solicitar certificado de nacimiento apostillado
- [ ] Solicitar antecedentes penales apostillados
- [ ] Traducir títulos académicos al alemán/francés (traductor jurado)
- [ ] Apostillar títulos universitarios
- [ ] Sacar foto tipo pasaporte formato suizo (35x45mm, fondo blanco)
- [ ] Si casado: apostillar partida de matrimonio

### Finanzas
- [ ] Ahorrar mínimo CHF 5,000 (ideal CHF 10,000+)
- [ ] Abrir cuenta Revolut o Wise (temporal hasta tener cuenta suiza)
- [ ] Notificar a tu banco actual que viajarás a Suiza (evitar bloqueos de tarjeta)
- [ ] Conseguir tarjeta de crédito internacional (Visa/Mastercard)

---

## 📅 1 MES ANTES

### Trabajo Confirmado
- [ ] Firmar contrato de trabajo
- [ ] Empresa inicia tramitación permiso L o B
- [ ] Recibir carta de aprobación del permiso (Zusicherung)
- [ ] Confirmar fecha de inicio de trabajo

### Vivienda
- [ ] Buscar alojamiento temporal (primeros 2-4 semanas)
  - Opciones: Airbnb, hostels, WG compartida temporal
- [ ] Registrarse en portales de vivienda:
  - homegate.ch
  - immoscout24.ch
  - wgzimmer.ch (habitaciones compartidas)
- [ ] Preparar documentos para alquiler:
  - CV
  - Contrato de trabajo
  - Extractos bancarios (últimos 3 meses)
  - Cartas de recomendación de landlords anteriores

### Logística
- [ ] Comprar billete de avión (unidireccional)
- [ ] Contratar seguro de viaje temporal (hasta tener seguro suizo)
- [ ] Decidir qué llevar vs qué dejar:
  - Llevar: Ropa, documentos, laptop, objetos valiosos
  - Dejar/vender: Muebles, electrodomésticos (220V en Suiza)
- [ ] Reservar transporte desde aeropuerto a alojamiento

### Preparativos Finales
- [ ] Descargar apps útiles:
  - SBB Mobile (trenes suizos)
  - Neon (futuro banco)
  - DeepL (traductor)
  - Google Maps
- [ ] Avisar en trabajo actual (si aplica)
- [ ] Cancelar subscripciones y contratos en país de origen
- [ ] Dar de baja en seguros médicos/casa de país de origen

---

## 📅 SEMANA DEL VIAJE

### Última Verificación Documentos
- [ ] Pasaporte original
- [ ] Carta de aprobación permiso (Zusicherung)
- [ ] Contrato de trabajo firmado
- [ ] Certificados apostillados (originales + 2 copias)
- [ ] Fotos tipo pasaporte (llevar 6-8 extra)
- [ ] Reserva alojamiento temporal
- [ ] Tarjetas de crédito/débito

### Dinero
- [ ] Llevar CHF 500-1,000 en efectivo (para primeros días)
- [ ] Tarjeta con saldo suficiente para 2 semanas (Revolut/Wise)
- [ ] Anotar números de emergencia para bloqueo de tarjetas

### Equipaje
- [ ] Maleta con ropa para clima suizo (invierno puede ser -10°C)
- [ ] Laptop + cargadores (enchufe tipo J suizo - llevar adaptador universal)
- [ ] Medicinas personales (3 meses mínimo) + recetas traducidas
- [ ] Copias digitales de todos los documentos (Google Drive/email a ti mismo)

---

## 📅 PRIMEROS 3 DÍAS EN SUIZA

### Día 1: Llegada
- [ ] Llegar al alojamiento temporal
- [ ] Comprar SIM prepago suiza:
  - Swisscom (mejor cobertura): CHF 20-30
  - Salt, Sunrise (más baratos): CHF 10-20
  - Ubicaciones: Aeropuerto, estaciones de tren, Coop, Migros
- [ ] Activar número suizo
- [ ] Comprar pase de transporte semanal/mensual (Tageskarte, Monatsabo)
- [ ] Comprar comida básica (Migros, Coop, Aldi, Lidl)

### Día 2-3: Trámites Urgentes
- [ ] Encontrar tu Gemeinde (ayuntamiento local)
  - Buscar en: ch.ch + tu código postal
- [ ] Pedir cita en Gemeinde (si cantón lo requiere - Zürich, Genève, Basel)
- [ ] Preparar documentos para registro:
  - Pasaporte original
  - Foto pasaporte
  - Contrato trabajo
  - Contrato alquiler o confirmación alojamiento temporal
  - Permiso de trabajo (Zusicherung)
  - Certificado nacimiento apostillado

---

## 📅 SEMANA 1 (Días 4-7)

### Registro Oficial
- [ ] **IR AL GEMEINDE** (CRÍTICO - primeros 14 días)
- [ ] Completar formulario de registro (Anmeldung)
- [ ] Pagar tasas de registro (CHF 60-120 efectivo)
- [ ] Recibir confirmación temporal de registro
- [ ] Solicitar permiso de residencia físico (tarjeta)

### Cuenta Bancaria
- [ ] Descargar app Neon o Zak
- [ ] Completar video-identificación
- [ ] Subir documentos:
  - Pasaporte
  - Confirmación registro Gemeinde
  - Permiso de trabajo
- [ ] Esperar aprobación (1-3 días)
- [ ] Recibir IBAN suizo CH...

### Vivienda Permanente
- [ ] Aplicar a 10-20 pisos/habitaciones
- [ ] Preparar dossier completo:
  - CV
  - Contrato trabajo
  - Extracto bancario
  - Betreibungsregisterauszug (registro deudas - pedir en Gemeinde)
- [ ] Ir a visitas de pisos
- [ ] Firmar contrato de alquiler

---

## 📅 SEMANA 2-3

### Seguro Médico (OBLIGATORIO - max 3 meses desde llegada)
- [ ] Comparar aseguradoras en priminfo.ch
- [ ] Elegir franquicia (CHF 2,500 recomendado para jóvenes)
- [ ] Contratar seguro online:
  - Assura (más barata)
  - Swica, CSS, Helsana (más caras)
- [ ] Recibir confirmación y tarjeta de seguro

### Trabajo
- [ ] Primer día de trabajo
- [ ] Recibir info sobre:
  - Pensionskasse (fondo de pensiones)
  - Nómina y deducciones
  - Horarios, vacaciones
- [ ] Firmar documentos empresa

### Instalación
- [ ] Mudarse a vivienda permanente
- [ ] Comprar muebles básicos:
  - IKEA (Spreitenbach, cerca Zürich)
  - Conforama
  - Pfister
  - Opciones baratas: Ricardo.ch (como eBay), Tutti.ch
- [ ] Setup internet casa (Swisscom, Sunrise, Salt)
- [ ] Registrar nuevo domicilio en Gemeinde (cambio de dirección)

---

## 📅 SEMANA 4 - MES 2

### Integración
- [ ] Inscribirse en curso de alemán:
  - Migros Klubschule
  - Volkshochschule (VHS)
  - Online: Goethe-Institut
- [ ] Unirse a grupos de meetup/deportes/hobbies
- [ ] Activar Twint (app de pagos suiza)
- [ ] Conseguir abono de transporte mensual/anual

### Finanzas
- [ ] Revisar primera nómina (Lohnabrechnung)
- [ ] Verificar deducciones:
  - Quellensteuer (impuestos)
  - AHV/IV (seguridad social)
  - Pensionskasse
  - Seguro accidentes (NBU)
- [ ] Solicitar subsidio seguro médico si ganas < CHF 5,000/mes
  - Formulario en Gemeinde: "Prämienverbilligung"

---

## 📅 MES 3

### Permisos
- [ ] Recibir permiso L o B físico (tarjeta)
- [ ] Verificar que datos sean correctos
- [ ] Llevar siempre el permiso contigo (obligatorio)

### Documentos Suizos
- [ ] Si tienes coche: Cambiar licencia de conducir a suiza
  - Plazo: 12 meses desde llegada
  - Oficina: Strassenverkehrsamt del cantón
- [ ] Abrir 2do pilar (Pensionskasse) si aún no lo hizo tu empleador
- [ ] Abrir 3er pilar (ahorro privado) opcional pero recomendado

---

## ✅ CHECKLIST DE EMERGENCIAS

### Números Importantes
- [ ] **Emergencias médicas:** 144
- [ ] **Policía:** 117
- [ ] **Bomberos:** 118
- [ ] **Emergencia general:** 112
- [ ] **Bloqueo tarjeta bancaria:** +41 [número de tu banco]
- [ ] **Embajada de tu país en Suiza:** [buscar y anotar]

### Apps Esenciales Instaladas
- [ ] SBB Mobile (transporte)
- [ ] Neon / Zak (banco)
- [ ] Twint (pagos)
- [ ] DeepL (traductor)
- [ ] MeteoSwiss (clima)
- [ ] Too Good To Go (comida barata)
- [ ] Sirene (alertas emergencias)

---

## 💰 PRESUPUESTO ESTIMADO PRIMEROS 3 MESES

| Concepto | CHF |
|----------|-----|
| Alquiler primer mes + depósito | 3,600 |
| Comida (CHF 400/mes × 3) | 1,200 |
| Seguro médico (CHF 300/mes × 3) | 900 |
| Transporte (CHF 150/mes × 3) | 450 |
| Teléfono/Internet (CHF 80/mes × 3) | 240 |
| Muebles básicos | 500 |
| Imprevistos | 500 |
| **TOTAL MÍNIMO** | **7,390** |

💡 **Recomendación:** Llegar con CHF 10,000-12,000 ahorrados para estar tranquilo.

---

## 📚 RECURSOS ÚTILES

**Webs Oficiales:**
- ch.ch (portal gobierno suizo)
- sem.admin.ch (migraciones)
- priminfo.ch (comparador seguros)

**Comunidades:**
- Facebook: "Españoles en Suiza", "Latinos en Zürich"
- Telegram: [buscar grupos por ciudad]
- Reddit: r/Switzerland, r/askswitzerland

**Apps Comparación Precios:**
- comparis.ch (seguros, telefonía, etc.)
- doodle.ch (precios supermercados)

---

## ✨ TIPS FINALES

1. **No dejes nada para última hora** - Los trámites suizos son lentos
2. **Aprende alemán básico YA** - Incluso A1 te ayudará mucho
3. **Sé puntual** - 5 minutos tarde = 30 minutos tarde en mentalidad suiza
4. **Guarda TODOS los recibos** - Los necesitarás para impuestos
5. **Pregunta siempre** - Los suizos aprecian que intentes hacerlo correcto
6. **Ten paciencia** - Los primeros 3 meses son los más duros, después mejora

---

¡Mucha suerte en tu aventura suiza! 🇨🇭

---

*Checklist creada por Swiss Starter Pack - HispanosEnSuiza*
*Versión 1.0 - Noviembre 2026*
