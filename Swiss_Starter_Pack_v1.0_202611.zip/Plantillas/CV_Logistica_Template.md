# PLANTILLA CV - SECTOR LOGÍSTICA
## Formato Suizo Optimizado 2026

---

**INSTRUCCIONES DE USO:**
1. Reemplaza TODOS los textos entre [CORCHETES] con tu información real
2. Mantén el formato y estructura
3. Traduce al alemán usando DeepL.com
4. Exporta a PDF (máx 2 páginas)
5. Agrega foto profesional en esquina superior derecha (35x45mm)

---

# [TU NOMBRE COMPLETO]
## [Tu Título Profesional en Alemán]
### Ejemplo: Lagerist | Logistikmitarbeiter | Staplerfahrer

---

## KONTAKT / CONTACTO

**Adresse:** [Calle], [Número], [Código Postal] [Ciudad], Schweiz

**Telefon:** +41 [tu número suizo - consigue SIM prepago si no tienes]

**Email:** [tu.email@gmail.com] *(usar Gmail, no Hotmail)*

**LinkedIn:** linkedin.com/in/[tu-perfil]

**Geburtsdatum:** [DD.MM.YYYY]

**Nationalität:** [Tu Nacionalidad] ([Permiso B / Permiso L / "B-Bewilligung in Bearbeitung"])

---

## BERUFSERFAHRUNG / EXPERIENCIA LABORAL

### [Cargo en alemán] | [Nombre Empresa], [Ciudad, País]
**[MM.YYYY] – [MM.YYYY o "Heute" si es actual]**

- [Logro específico con número o porcentaje - Ejemplo: "Verwaltung von 500+ Paletten täglich mit 98,5% Genauigkeit"]
- [Responsabilidad clave - Ejemplo: "Leitung eines Teams von 5 Mitarbeitern im Schichtbetrieb"]
- [Mejora o proyecto - Ejemplo: "Implementierung eines neuen WMS-Systems, Reduzierung der Fehlerquote um 40%"]
- [Sistema/herramienta usada - Ejemplo: "SAP WM und RF-Scanner für Bestandsverwaltung"]
- [Indicador de desempeño - Ejemplo: "Erreichen von 120% des monatlichen KPI-Ziels"]

### [Segundo Cargo] | [Empresa], [Ciudad, País]
**[MM.YYYY] – [MM.YYYY]**

- [4-5 bullets igual que arriba, enfocados en LOGROS no en tareas]
- Usa números: porcentajes, cantidades, ahorro de tiempo/dinero
- Verbos de acción: Verwaltete, Leitete, Implementierte, Optimierte, Reduzierte

---

## AUSBILDUNG / EDUCACIÓN

### [Título] | [Universidad], [Ciudad, País]
**[YYYY] – [YYYY]**

**Schwerpunkt:** [Especialización si la hay]

*Nota: Si tu título no está convalidado en Suiza, añade:*
"Anerkennung in der Schweiz: [In Bearbeitung / Nicht erforderlich für diese Position]"

---

## SPRACHEN / IDIOMAS

- **Spanisch:** Muttersprache *(lengua materna)*
- **Deutsch:** [A1 / A2 / B1 / B2] [(Goethe-Zertifikat [Nivel], [Mes] [Año])]
- **Englisch:** [A2 / B1 / B2 / C1] [(fließend / verhandlungssicher)]
- **[Otro idioma si aplica]:** [Nivel]

---

## FÄHIGKEITEN & KOMPETENZEN / HABILIDADES

### Software & Systeme
- SAP WM / EWM ([Grundkenntnisse / Fortgeschritten / Experte])
- WMS-Systeme: [nombres específicos que conoces]
- RF-Scanner und mobile Geräte
- MS Office: Excel ([Fortgeschritten - Pivot-Tabellen, VLookup]), Word, Outlook

### Zertifikate & Lizenzen
- **Staplerschein:** [Kategorie R1, R2, R3 / "in der Schweiz zu erneuern"]
- **[Otro certificado relevante]:** [Detalles]

### Logistik-Kompetenzen
- Kommissionierung (Picking): [Anzahl Artikel/Tag]
- Ein-/Auslagerung Hochregallager
- Bestandsverwaltung und Inventur
- Qualitätskontrolle Wareneingang
- Versandvorbereitung und Verpackung
- [Añade habilidades específicas de tu experiencia]

---

## WEITERE INFORMATIONEN / INFORMACIÓN ADICIONAL

- **Führerschein:** Kategorie B (EU-Führerschein, [gültig bis YYYY / "in CH-Führerschein umgetauscht"])
- **Verfügbarkeit:** Sofort / Ab [DD.MM.YYYY]
- **Schichtarbeit:** Bereit für Früh-, Spät- und Nachtschicht
- **Wochenendarbeit:** Flexibel verfügbar
- **Arbeitspensum:** 100% (Vollzeit) / [oder porcentaje que buscas]

---

## REFERENZEN / REFERENCIAS

Auf Anfrage verfügbar / Disponible a solicitud

*O incluye 2 referencias directamente:*

**[Nombre Referencia 1]**
[Cargo], [Empresa anterior]
Tel: +[código país] [número]
Email: [email]

**[Nombre Referencia 2]**
[Cargo], [Empresa anterior]
Tel: +[código país] [número]
Email: [email]

---

## 📌 TIPS FINALES:

1. **FOTO:** Esquina superior derecha, 35x45mm, fondo blanco, ropa formal
2. **LONGITUD:** Máximo 2 páginas (ideal 1.5 páginas)
3. **FORMATO:** PDF con nombre: "CV_[TUNOMBRE]_Lagerist_2026.pdf"
4. **IDIOMA:** TODO en alemán (usa DeepL para traducir esta plantilla)
5. **NÚMEROS:** Usa puntos suizos: 5.000 (no 5,000)
6. **FECHAS:** Formato suizo: DD.MM.YYYY (no DD/MM/YYYY)
7. **SIN ERRORES:** Haz revisar el alemán por alguien nativo o usa servicios de corrección

---

**PALABRAS CLAVE PARA LOGÍSTICA (incluir en tu CV):**

Lagerverwaltung, Kommissionierung, Bestandskontrolle, Wareneingang, Warenausgang,
Inventur, Qualitätssicherung, Versand, Hochregallager, Flurförderzeuge, SAP WM,
Staplerfahrer, Schichtbetrieb, Teamarbeit, Präzision, Effizienz, Termintreue

---

*Plantilla creada por Swiss Starter Pack - HispanosEnSuiza*
*Versión 1.0 - Noviembre 2026*
