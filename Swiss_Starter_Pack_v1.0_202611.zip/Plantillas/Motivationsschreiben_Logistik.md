# PLANTILLA CARTA DE MOTIVACIÓN - LOGÍSTICA
## Motivationsschreiben Lagerist / Logistikmitarbeiter

---

**INSTRUCCIONES:**
1. Reemplaza TODO entre [CORCHETES] con tu información
2. Personaliza cada carta para cada empresa (muy importante)
3. Mantén máximo 1 página A4
4. Usa DeepL para verificar el alemán
5. Guarda como PDF: "Motivationsschreiben_[TUNOMBRE]_[EMPRESA].pdf"

---

[Tu Nombre Completo]
[Tu Dirección en Suiza]
[Código Postal] [Ciudad]
[+41 XX XXX XX XX]
[tu.email@gmail.com]

                                                                [Ciudad], [TT.MM.YYYY]

[Nombre de la Empresa]
[Departamento - Ejemplo: Personalabteilung / z.H. Frau/Herr [Nombre si lo sabes]]
[Dirección Empresa]
[Código Postal] [Ciudad]


**Betreff: Bewerbung als [Cargo exacto del anuncio] – Referenz [Número si hay]**


Sehr geehrte [Frau Müller / Herr Schmidt / Damen und Herren],

**[PÁRRAFO 1: EL GANCHO - 3-4 líneas]**

[Oración de apertura que muestra que investigaste la empresa + conecta tu experiencia]

*Ejemplo:*
Ihre Stellenanzeige für einen Lageristen mit SAP-Kenntnissen und Erfahrung im Hochregallager hat mein Interesse geweckt. Als Logistikmitarbeiter mit [X] Jahren Berufserfahrung in der Lagerverwaltung und fundierten Kenntnissen in SAP WM bin ich überzeugt, dass ich Ihr Team optimal verstärken kann. [Añade algo específico de la empresa: "Besonders beeindruckt bin ich von Ihrer kürzlichen Expansion nach [lugar] und Ihrer Auszeichnung als [premio]."]

**[PÁRRAFO 2: TU VALOR - 5-6 líneas]**

[Demuestra con NÚMEROS y HECHOS que eres el candidato ideal]

*Ejemplo:*
In meiner aktuellen Position bei [Empresa] in [País] bin ich verantwortlich für die Verwaltung eines Lagers mit über [X.000] Palettenplätzen und leite ein Team von [X] Mitarbeitern. Durch die Optimierung unserer Kommissionierungsprozesse konnte ich die Durchlaufzeit um [X]% reduzieren und gleichzeitig die Fehlerquote von [X]% auf [X]% senken. Meine umfangreiche Erfahrung mit SAP WM, WMS-Systemen und RF-Scannern ermöglicht mir einen sofortigen produktiven Einsatz in Ihrem Unternehmen. Zusätzlich verfüge ich über einen gültigen Staplerschein (Kategorien R1-R3) und bin mit den SUVA-Sicherheitsvorschriften vertraut.

[Añade mención de idiomas:]
Meine Deutschkenntnisse auf [A2/B1/B2]-Niveau (Goethe-Zertifikat, [Monat/Jahr]) sowie fließende Englisch- und Spanischkenntnisse garantieren eine reibungslose Kommunikation mit Kollegen, Lieferanten und internationalen Partnern.

**[PÁRRAFO 3: CALL TO ACTION + CIERRE - 2-3 líneas]**

[Disponibilidad + solicitud de entrevista + agradecimiento]

*Ejemplo:*
Mit meiner [B-Bewilligung / "bevorstehenden B-Bewilligung"] kann ich ab dem [TT.MM.YYYY / "sofort"] bei Ihnen starten. Gerne überzeuge ich Sie in einem persönlichen Gespräch von meiner Motivation und meinen Fähigkeiten. Für Rückfragen stehe ich Ihnen jederzeit unter [+41 XX XXX XX XX] zur Verfügung.

Ich freue mich auf Ihre positive Rückmeldung.

Mit freundlichen Grüssen


[Dein Name]


**Anlagen:**
- Lebenslauf
- Arbeitszeugnisse
- [Goethe-Zertifikat B1]
- [Staplerschein]
- [B-Bewilligung (Kopie)]

---

## 🎯 VERSIONES ADAPTADAS PARA DIFERENTES SITUACIONES:

### VERSIÓN 1: SI APLICAS SIN ALEMÁN PERFECTO (A2-B1)

*Modificar párrafo sobre idiomas:*

"Meine Deutschkenntnisse befinden sich aktuell auf A2-Niveau und ich nehme seit [X] Monaten wöchentlich Sprachunterricht, um mich stetig zu verbessern. In meiner bisherigen Berufslaufbahn habe ich in multikulturellen Teams gearbeitet und dabei die Wichtigkeit klarer Kommunikation erkannt. Ergänzend verfüge ich über fließende Englischkenntnisse (B2) und Spanisch als Muttersprache."

---

### VERSIÓN 2: SI APLICAS DESDE TU PAÍS (SIN PERMISO AÚN)

*Modificar párrafo de cierre:*

"Ich bin bereit, zeitnah in die Schweiz zu ziehen und bin flexibel bezüglich des Starttermins. Mit Ihrer Zusage kann ich die Arbeitserlaubnis kurzfristig beantragen, was in der Regel 4-6 Wochen in Anspruch nimmt. Für ein Vorstellungsgespräch bin ich gerne bereit, per Videocall (Zoom/Teams) oder persönlich nach Zürich zu reisen."

---

### VERSIÓN 3: SI ES APLICACIÓN DIRECTA (Sin oferta publicada - Initiativbewerbung)

*Cambiar el Betreff:*
**Betreff: Initiativbewerbung als Lagerist – [Tu Nombre]**

*Modificar párrafo 1:*

"Als erfahrener Logistikmitarbeiter mit [X] Jahren Berufserfahrung im Hochregallager möchte ich mich initiativ bei Ihrem Unternehmen bewerben. Ihre Position als [führender Logistikdienstleister / innovatives Unternehmen / etc.] in der Region [Stadt] sowie Ihre modernen Lagerungsanlagen haben mein Interesse geweckt. Ich bin überzeugt, dass meine Expertise in SAP WM und meine nachgewiesenen Erfolge in der Prozessoptimierung einen Mehrwert für Ihr Team darstellen."

---

### VERSIÓN 4: SI ESTÁS EN SUIZA CON TRABAJO TEMPORAL Y BUSCAS FIJO

*Modificar inicio del párrafo 2:*

"Seit [X] Monaten arbeite ich als Lagerist bei [Temp-Agentur] in verschiedenen Einsätzen in der Schweiz und habe dabei umfassende Erfahrungen in [Branchen] gesammelt. Nun suche ich eine langfristige Festanstellung, um meine Expertise gezielt einzubringen und kontinuierlich weiterzuentwickeln."

---

## ❌ ERRORES FATALES A EVITAR:

1. **NO usar "Sehr geehrte Damen und Herren"** si sabes el nombre del recruiter
   - Busca en LinkedIn o llama a la empresa para preguntar: "An wen kann ich meine Bewerbung richten?"

2. **NO hacer la carta genérica**
   - SIEMPRE menciona algo específico de la empresa (premio, expansión, producto, valores)

3. **NO escribir más de 1 página**
   - Los suizos valoran la concisión

4. **NO usar Google Translate**
   - Usa DeepL (mucho mejor) + revisión nativa si es posible

5. **NO enviar PDF con errores tipográficos**
   - Revisa 3 veces antes de enviar

6. **NO olvidar personalizar el Betreff**
   - Usa el código de referencia si la oferta lo menciona

---

## ✅ CHECKLIST ANTES DE ENVIAR:

- [ ] Nombre del recruiter correcto (Frau/Herr + apellido)
- [ ] Nombre de empresa correcto (sin errores)
- [ ] Fecha actual en formato suizo (TT.MM.YYYY)
- [ ] Cargo exacto como aparece en el anuncio
- [ ] Números específicos de tus logros incluidos
- [ ] Alemán revisado (DeepL + nativo si es posible)
- [ ] PDF nombrado: "Motivationsschreiben_[NOMBRE]_[EMPRESA].pdf"
- [ ] Todos los anexos mencionados están incluidos

---

## 🔑 PALABRAS CLAVE IMPORTANTES PARA LOGÍSTICA:

Lagerverwaltung, Bestandskontrolle, SAP WM, Kommissionierung, Hochregallager,
Wareneingang, Warenausgang, Qualitätssicherung, Teamleitung, Prozessoptimierung,
Effizienzsteigerung, Fehlerquote, Staplerfahrer, Schichtbetrieb, Termintreue

---

*Plantilla creada por Swiss Starter Pack - HispanosEnSuiza*
*Versión 1.0 - Noviembre 2026*
