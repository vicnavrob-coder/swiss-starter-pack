# 💰 PRESUPUESTO MENSUAL SUIZA
## Template Editable - Planifica tus Finanzas

---

## 📊 CÓMO USAR ESTA PLANTILLA

1. **Ingresa tu salario bruto** en la sección de ingresos
2. **Ajusta los gastos** según tu situación real
3. **Compara** el resultado con los promedios por cantón
4. **Optimiza** las áreas donde gastas más

💡 **Los números entre [corchetes] son editables - reemplázalos con tus datos reales**

---

## 💵 INGRESOS MENSUALES

| Concepto | CHF |
|----------|-----|
| **Salario Bruto (Bruttolohn)** | [5,000] |
| | |
| **DEDUCCIONES AUTOMÁTICAS:** | |
| ./. Impuestos (Quellensteuer) ~12-18% | -[620] |
| ./. AHV/IV/EO (seguridad social) ~5.5% | -[275] |
| ./. ALV (seguro desempleo) ~2.2% | -[110] |
| ./. NBU (seguro accidentes no laborales) ~1-1.2% | -[60] |
| ./. Pensionskasse (2º pilar) ~5-7% | -[250] |
| | |
| **= SALARIO NETO (Nettolohn)** | **[3,685]** |

---

## 🏠 GASTOS FIJOS MENSUALES

### Vivienda

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Alquiler (Miete)** | [1,200] | *Studio 1 ambiente* |
| Depósito mensual (Kaution ahorrada) | [100] | *2-3 meses de alquiler* |
| Nebenkosten (incluidos) | [0] | *O separados si aplica* |
| Electricidad | [30] | *Si no incluida* |
| Internet + TV | [50] | *Swisscom, Salt, Sunrise* |
| **SUBTOTAL VIVIENDA** | **[1,380]** | **37% del neto** |

### Seguros Obligatorios

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Seguro Médico (Krankenversicherung)** | [280] | *Franquicia 2,500* |
| Seguro Responsabilidad Civil (Haftpflicht) | [10] | *Recomendado* |
| Seguro Hogar (Hausrat) | [8] | *Opcional* |
| **SUBTOTAL SEGUROS** | **[298]** | **8% del neto** |

### Transporte

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Abono Transporte Mensual** | [70] | *GA Halbtax o zona local* |
| O Bicicleta/Coche (combustible) | [0] | *Alternativa* |
| **SUBTOTAL TRANSPORTE** | **[70]** | **2% del neto** |

### Comunicación

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Móvil** | [25] | *Prepago o contrato* |
| Spotify/Netflix/Subscripciones | [20] | *Opcional* |
| **SUBTOTAL COMUNICACIÓN** | **[45]** | **1% del neto** |

---

## 🛒 GASTOS VARIABLES MENSUALES

### Alimentación

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Supermercado (Groceries)** | [400] | *Lidl, Aldi, Migros, Coop* |
| Restaurantes/Cafés | [100] | *2-3 veces/mes* |
| **SUBTOTAL ALIMENTACIÓN** | **[500]** | **14% del neto** |

💡 **Tips para ahorrar en comida:**
- Comprar en Lidl/Aldi: -30% vs Coop/Migros
- Productos marca blanca: -40%
- Too Good To Go app: Comida a CHF 3-6
- Mercados locales sábados por la mañana

### Otros Gastos

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Higiene Personal y Limpieza** | [50] | *Dm, Müller* |
| Ropa | [80] | *Promedio mensual* |
| Ocio/Entretenimiento | [100] | *Cine, deportes, salidas* |
| Curso Alemán | [150] | *Volkshochschule, opcional* |
| Peluquería/Barbería | [30] | *1 vez/mes* |
| **SUBTOTAL OTROS** | **[410]** | **11% del neto** |

---

## 💾 AHORRO E IMPREVISTOS

| Concepto | CHF | Notas |
|----------|-----|-------|
| **Ahorro Mensual (3er Pilar)** | [200] | *Deducible de impuestos* |
| Fondo Emergencias | [100] | *Objetivo: 3 meses gastos* |
| Envío dinero familia (si aplica) | [150] | *Opcional* |
| **SUBTOTAL AHORRO** | **[450]** | **12% del neto** |

---

## 📈 RESUMEN MENSUAL

| Categoría | CHF | % del Neto |
|-----------|-----|------------|
| **INGRESOS NETOS** | **3,685** | **100%** |
| | | |
| **GASTOS FIJOS** | | |
| Vivienda | -1,380 | -37% |
| Seguros | -298 | -8% |
| Transporte | -70 | -2% |
| Comunicación | -45 | -1% |
| **GASTOS VARIABLES** | | |
| Alimentación | -500 | -14% |
| Otros | -410 | -11% |
| **AHORRO** | -450 | -12% |
| | | |
| **TOTAL GASTOS** | **-3,153** | **-86%** |
| | | |
| **= SOBRANTE MES** | **+532** | **+14%** |

---

## 🎯 ESCENARIOS POR SALARIO

### SALARIO BAJO (CHF 4,000 bruto / CHF 3,000 neto)

**Presupuesto Ajustado:**
- Alquiler: CHF 800 (habitación compartida)
- Comida: CHF 350 (cocinar siempre)
- Seguro: CHF 260 (Assura, franquicia alta)
- Transporte: CHF 50 (bicicleta + ocasional tren)
- Ocio: CHF 50 (mínimo)
- **Ahorro posible:** CHF 100-200/mes

---

### SALARIO MEDIO (CHF 5,500 bruto / CHF 4,200 neto)

**Presupuesto Ajustado:**
- Alquiler: CHF 1,300 (studio 1.5 ambientes)
- Comida: CHF 500 (mix supermercado + restaurante)
- Seguro: CHF 280
- Transporte: CHF 80 (abono mensual)
- Ocio: CHF 150
- **Ahorro posible:** CHF 400-600/mes

---

### SALARIO ALTO (CHF 7,500+ bruto / CHF 5,500+ neto)

**Presupuesto Ajustado:**
- Alquiler: CHF 1,800 (2 ambientes)
- Comida: CHF 600 (flexibilidad total)
- Seguro: CHF 300
- Transporte: CHF 100 (coche propio posible)
- Ocio: CHF 300
- **Ahorro posible:** CHF 800-1,200/mes

---

## 🏙️ COMPARATIVA POR CANTÓN

### Zürich (Ciudad)

| Gasto | CHF/mes |
|-------|---------|
| Alquiler 1 ambiente | 1,400-1,800 |
| Comida | 500-600 |
| Transporte | 85 (zona 110) |
| **COSTO VIDA** | **ALTO** |

---

### Luzern

| Gasto | CHF/mes |
|-------|---------|
| Alquiler 1 ambiente | 1,100-1,400 |
| Comida | 450-550 |
| Transporte | 70 |
| **COSTO VIDA** | **MEDIO** |

---

### Zug

| Gasto | CHF/mes |
|-------|---------|
| Alquiler 1 ambiente | 1,600-2,000 |
| Comida | 500-600 |
| Transporte | 75 |
| **COSTO VIDA** | **MUY ALTO** |
| **Ventaja** | Impuestos más bajos |

---

### Bern

| Gasto | CHF/mes |
|-------|---------|
| Alquiler 1 ambiente | 1,000-1,300 |
| Comida | 450-550 |
| Transporte | 75 |
| **COSTO VIDA** | **MEDIO** |

---

### Genève

| Gasto | CHF/mes |
|-------|---------|
| Alquiler 1 ambiente | 1,500-2,000 |
| Comida | 550-650 |
| Transporte | 70 |
| **COSTO VIDA** | **MUY ALTO** |

---

## 💡 TIPS PARA OPTIMIZAR TU PRESUPUESTO

### 🏠 Ahorra en Vivienda (-30%)

- Busca WG (piso compartido): -CHF 400-600/mes
- Vive en cantones vecinos más baratos (ej: Aargau cerca de Zürich)
- Negocia Nebenkosten incluidos en alquiler

### 🛒 Ahorra en Comida (-25%)

- Compra en Lidl/Aldi vs Coop/Migros: -30%
- Usa app "Too Good To Go": Comida de restaurantes a CHF 3-6
- Compra marcas blancas: -40%
- Cocina en batch (meal prep domingo)

### 🚇 Ahorra en Transporte (-40%)

- Bicicleta en vez de transporte público: -CHF 70/mes
- Halbtax (50% descuento trenes): CHF 185/año si viajas seguido
- Combina caminata + transporte público

### 📱 Ahorra en Telefonía (-50%)

- Usa Prepago (Aldi Mobile, Wingo): CHF 10-15/mes
- Evita contratos largos de Swisscom

### 🏥 Ahorra en Seguro Médico (-30%)

- Franquicia alta (CHF 2,500): -CHF 100-150/mes
- Cambiar a Assura (más barata): -CHF 50-100/mes vs marcas premium
- Usar comparador priminfo.ch cada año

---

## 📊 CALCULADORA INTERACTIVA

**¿Qué % de tu neto gastas en cada categoría?**

- ✅ **Alquiler:** Ideal 30-35% | Máximo 40%
- ✅ **Seguros:** Ideal 8-10%
- ✅ **Comida:** Ideal 12-15%
- ✅ **Ahorro:** Mínimo 10% | Ideal 15-20%

**Regla 50/30/20:**
- 50% Necesidades (vivienda, comida, seguros)
- 30% Gustos (ocio, restaurantes, hobbies)
- 20% Ahorro

---

## 🚨 RED FLAGS

**PELIGRO si:**
- ❌ Gastas >45% en alquiler
- ❌ No ahorras nada
- ❌ Usas tarjeta de crédito para gastos básicos
- ❌ Llegas a fin de mes con CHF 0

**SOLUCIÓN:**
1. Reduce alquiler (compartir piso)
2. Corta gastos variables (restaurantes, ocio)
3. Busca trabajo mejor pagado o segundo trabajo temporal
4. Considera mudarte a cantón más barato

---

## 💰 METAS FINANCIERAS

**Primer año en Suiza:**
- [ ] Ahorrar 3 meses de gastos (Fondo emergencia): ~CHF 9,000
- [ ] Abrir 3er pilar (ahorro privado)
- [ ] Pagar deudas de mudanza (si las hay)

**Segundo año:**
- [ ] Ahorrar 6 meses de gastos: ~CHF 18,000
- [ ] Maximizar 3er pilar (CHF 7,056/año - deducible impuestos)
- [ ] Considerar inversiones (acciones, ETFs)

---

## 📥 DESCARGA VERSIÓN EXCEL

*[Incluir link a Excel con fórmulas automáticas cuando esté disponible]*

---

## ✅ CHECKLIST MENSUAL

- [ ] Revisar extracto bancario
- [ ] Categorizar gastos (apps: YNAB, Splitwise, Excel)
- [ ] Comparar presupuesto real vs planificado
- [ ] Ajustar próximo mes según aprendizajes
- [ ] Verificar que ahorros automáticos se ejecutaron

---

¿Necesitas ayuda para optimizar tu presupuesto? Únete a nuestra comunidad de HispanosEnSuiza para tips y consejos! 🇨🇭

---

*Template creado por Swiss Starter Pack - HispanosEnSuiza*
*Versión 1.0 - Noviembre 2026*
