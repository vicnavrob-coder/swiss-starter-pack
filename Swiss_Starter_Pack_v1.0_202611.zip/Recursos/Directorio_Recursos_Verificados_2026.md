# 📚 DIRECTORIO DE RECURSOS VERIFICADOS SUIZA
## Actualizado: Noviembre 2026

---

## 🔍 BÚSQUEDA DE EMPLEO

### Portales de Trabajo Principales

**Jobs.ch** ⭐ (Líder en Suiza)
- URL: https://www.jobs.ch
- Idioma: Alemán/Francés/Italiano
- Filtros: Por cantón, salario, jornada
- App móvil: iOS y Android
- **Tip:** Configurar alertas de empleo por email

**Indeed Suiza**
- URL: https://ch.indeed.com
- Idioma: Multiidioma (incluye español en búsqueda)
- Base datos: Internacional + local
- **Tip:** Usar filtro "últimas 24 horas" para aplicar rápido

**JobScout24**
- URL: https://www.jobscout24.ch
- Idioma: Alemán/Francés
- Especialidad: Puestos cualificados
- Perfil empresa: Reseñas de empleados

**LinkedIn Jobs**
- URL: https://www.linkedin.com/jobs
- Idioma: Multiidioma
- **Ventaja:** Networking + aplicaciones
- **Tip:** Perfil en alemán aumenta visibilidad 300%

**Jobup.ch**
- URL: https://www.jobup.ch
- Idioma: Alemán/Francés
- Sectores: Todos
- **Tip:** Bueno para Suiza romanda (francófona)

**XING Jobs** (Red profesional alemana)
- URL: https://www.xing.com/jobs
- Idioma: Alemán
- Mercado: DACH (Alemania, Austria, Suiza)

---

### Agencias de Empleo Temporal (Zeitarbeit)

**Adecco Suiza** ⭐
- URL: https://www.adecco.ch
- Sectores: Logística, oficina, producción, hostelería
- Presencia: Oficinas en todas las ciudades
- **Teléfono:** +41 44 878 88 88
- **Tip:** Aceptan candidatos sin alemán perfecto
- **Proceso:** Registro online → entrevista presencial → colocación

**Randstad Suiza**
- URL: https://www.randstad.ch
- Sectores: Industria, IT, finanzas, logística
- **Ventaja:** Contratos temporales que se convierten en fijos
- **Tip:** Registrarse aunque no haya oferta activa

**Manpower Suiza**
- URL: https://www.manpower.ch
- Sectores: Oficina, logística, industrial
- **Especial:** Programas de formación gratuitos

**Kelly Services**
- URL: https://www.kellyservices.ch
- Sectores: Ciencia, tecnología, ingeniería
- **Tip:** Buenos salarios temporales (CHF 25-35/hora)

**Synergie**
- URL: https://www.synergie.ch
- Sectores: Construcción, producción, logística
- Presencia: Fuerte en Suiza alemana

---

### Portales Especializados

**Gastrojobs.ch** (Hostelería)
- URL: https://www.gastrojobs.ch
- Puestos: Cocina, servicio, hotel, limpieza
- **Ventaja:** Muchos puestos sin alemán requerido

**Bau-Stellen.ch** (Construcción)
- URL: https://www.bau-stellen.ch
- Sectores: Albañilería, electricidad, fontanería
- **Tip:** Buenos salarios (CHF 4,500-7,000/mes)

**ITjobs.ch** (Tecnología)
- URL: https://www.itjobs.ch
- Sectores: Desarrollo, infraestructura, ciberseguridad
- Salarios: CHF 80,000-140,000/año

**MedJobs.ch** (Salud)
- URL: https://www.medjobs.ch
- Sectores: Enfermería, cuidados, fisioterapia
- **Alta demanda:** Enfermeros/as con certificación

---

## 🏥 SEGURO MÉDICO (Krankenversicherung)

### Comparadores Oficiales

**Priminfo.ch** ⭐ (Oficial del gobierno)
- URL: https://www.priminfo.ch
- **Función:** Comparar TODAS las aseguradoras
- **Ventaja:** 100% neutral, sin comisiones
- **Cómo usar:**
  1. Introducir código postal
  2. Seleccionar franquicia (CHF 300-2,500)
  3. Ver ranking por precio
  4. Contratar directamente con la aseguradora

**Comparis.ch** (Comparador privado)
- URL: https://www.comparis.ch/krankenkassen
- **Ventaja:** Interfaz más intuitiva
- **Tip:** Cobra comisión a aseguradoras, pero igual es útil

---

### Aseguradoras Más Baratas (2026)

**1. Assura** ⭐ (Más económica)
- URL: https://www.assura.ch
- Precio medio: CHF 269-320/mes (Zürich, franquicia 2,500)
- **Ventaja:** Precio bajo, cobertura completa
- **Contratación:** Online en 10 minutos
- **Idiomas:** Alemán, francés, italiano
- **Tip:** Mejor opción si eres joven y sano

**2. Sana24**
- URL: https://www.sanitas.com/sana24
- Precio medio: CHF 290-340/mes
- **Ventaja:** Solo consultas por teléfono/app (más barato)
- **Restricción:** No puedes ir directo al médico, debes llamar primero

**3. Swica**
- URL: https://www.swica.ch
- Precio medio: CHF 320-380/mes
- **Ventaja:** Buena red de médicos, app excelente
- **Tip:** Opción intermedia calidad/precio

**4. CSS**
- URL: https://www.css.ch
- Precio medio: CHF 340-400/mes
- **Ventaja:** Servicio en español disponible
- **Teléfono:** +41 58 277 11 11

**5. Helsana**
- URL: https://www.helsana.ch
- Precio medio: CHF 360-420/mes
- **Ventaja:** Mayor aseguradora, red amplia
- **Desventaja:** Más cara

---

### Subsidios (Prämienverbilligung)

**¿Quién tiene derecho?**
- Personas con ingresos < CHF 50,000/año (aproximado, varía por cantón)
- Familias con hijos
- Estudiantes

**Cómo solicitar:**
1. Ir a tu Gemeinde (ayuntamiento)
2. Pedir formulario "Prämienverbilligung"
3. Entregar con contrato de trabajo + nóminas
4. **Resultado:** Reducción de CHF 50-200/mes en el seguro

**Portales por cantón:**
- Zürich: https://www.svazurich.ch
- Luzern: https://gesundheit.lu.ch
- Bern: https://www.gef.be.ch

---

## 🏦 BANCOS Y FINANZAS

### Bancos Digitales (Recomendados para extranjeros)

**Neon** ⭐ (Más fácil para extranjeros)
- URL: https://www.neon-free.ch
- **Ventajas:**
  - Apertura 100% online en 10 minutos
  - Sin costes mensuales (CHF 0)
  - Acepta permisos L y B
  - Video-identificación desde casa
  - Tarjeta Mastercard gratis
- **Desventaja:** No tiene cuenta de ahorro con interés
- **Requisitos:** Permiso de trabajo + registro en Gemeinde
- **App:** iOS y Android (excelente, en alemán/francés)

**Zak** (Banco Cler)
- URL: https://www.zak.ch
- **Ventajas:**
  - CHF 0 costes si < 30 años
  - Tarjeta Debit Mastercard gratis
  - Cuenta de ahorro incluida
- **Requisitos:** Residencia en Suiza confirmada
- **Tip:** Buena opción si quieres ahorrar

**Raiffeisen**
- URL: https://www.raiffeisen.ch
- **Ventajas:**
  - Banco cooperativo (local)
  - Servicio personalizado
- **Desventaja:** Hay que ir presencial a abrir cuenta
- **Costes:** CHF 5-10/mes según cantón

---

### Bancos Tradicionales

**PostFinance** (Correo Suizo)
- URL: https://www.postfinance.ch
- **Ventajas:**
  - Red de oficinas más grande de Suiza
  - App excelente
  - Costes: CHF 5/mes (jóvenes gratis)
- **Tip:** Buena opción si necesitas efectivo frecuente

**UBS**
- URL: https://www.ubs.com/ch
- Costes: CHF 10-15/mes
- **Desventaja:** Caro para cuentas básicas
- **Ventaja:** Reputación internacional

**Credit Suisse** (ahora UBS)
- Fusionado con UBS en 2023
- No recomendado para nuevas cuentas

---

### Tarjetas Internacionales (Mientras abres banco suizo)

**Revolut**
- URL: https://www.revolut.com
- **Uso:** Temporal hasta tener IBAN suizo
- **Ventaja:** Sin comisiones en CHF, EUR, USD
- **Tip:** Plan gratuito suficiente

**Wise** (antes TransferWise)
- URL: https://wise.com
- **Uso:** Transferencias internacionales baratas
- **Ventaja:** Tipo de cambio real, sin markup
- **Tip:** Útil para enviar dinero a familia

---

### Ahorro y 3er Pilar (Säule 3a)

**VIAC** ⭐ (Inversión automática)
- URL: https://viac.ch
- **Función:** 3er pilar invertido en ETFs
- **Ventaja:** Deducible de impuestos (hasta CHF 7,056/año)
- **Rentabilidad:** 4-7% anual histórico
- **Mínimo:** CHF 0 (sin mínimo)

**Frankly** (ZKB)
- URL: https://www.frankly.ch
- Similar a VIAC, 100% digital

**NEON + Pillar** (Alianza)
- Cuenta 3a directa desde app Neon
- **Ventaja:** Todo en una sola app

---

## 📱 TELEFONÍA MÓVIL

### Operadores Prepago (Baratos)

**Aldi Mobile** ⭐
- URL: https://www.aldi-mobile.ch
- **Plan recomendado:** CHF 14.95/mes (3GB + llamadas ilimitadas)
- **Red:** Swisscom (mejor cobertura)
- **Compra:** Tiendas Aldi o online
- **Tip:** Mejor relación calidad/precio

**Wingo** (Swisscom low-cost)
- URL: https://www.wingo.ch
- Plan desde: CHF 19/mes (5GB)
- **Red:** Swisscom
- **Ventaja:** 5G incluido

**Salt**
- URL: https://www.salt.ch
- Plan desde: CHF 29.95/mes (datos ilimitados)
- **Ventaja:** Roaming UE incluido
- **App:** Gestión completa online

**Sunrise**
- URL: https://www.sunrise.ch
- Plan desde: CHF 24.95/mes
- **Ventaja:** Red propia (buena)

---

### Operadores Contrato (Si vas a quedarte 2+ años)

**Swisscom** (Premium)
- URL: https://www.swisscom.ch
- Desde: CHF 49/mes
- **Ventaja:** Mejor cobertura de Suiza (99%)
- **Desventaja:** Caro

**yallo** (Swisscom low-cost)
- URL: https://www.yallo.ch
- Desde: CHF 19/mes
- **Ventaja:** Red Swisscom, precio bajo

---

## 🇩🇪 APRENDER ALEMÁN

### Apps y Cursos Online

**Duolingo** (Gratis) ⭐
- URL: https://www.duolingo.com
- Nivel: A1-B1
- **Ventaja:** Gamificado, 10 min/día
- **Desventaja:** No enseña Schweizerdeutsch
- **Tip:** Hacer alemán estándar (Hochdeutsch) primero

**Babbel** (Pago)
- URL: https://www.babbel.com
- Precio: CHF 7-13/mes
- Nivel: A1-B2
- **Ventaja:** Estructurado, ejercicios de conversación

**Busuu** (Freemium)
- URL: https://www.busuu.com
- Precio: CHF 5-10/mes
- **Ventaja:** Correcciones de nativos

**GermanPod101** (Podcasts)
- URL: https://www.germanpod101.com
- **Ventaja:** Aprende escuchando
- **Tip:** Útil para commute en tren

**SwissGerman.ch** (Schweizerdeutsch) ⭐
- URL: https://www.swissgerman.ch
- **Función:** Diccionario Hochdeutsch ↔ Schweizerdeutsch
- **Tip:** Usar después de tener A2 en alemán estándar

---

### Cursos Presenciales en Suiza

**Migros Klubschule** ⭐ (Red nacional)
- URL: https://www.klubschule.ch
- **Ubicaciones:** Todas las ciudades
- Precio: CHF 600-900 por nivel (A1, A2, B1...)
- Formato: 2-3 clases/semana, 3 meses
- **Ventaja:** Certificado oficial reconocido
- **Tip:** Preguntar por descuentos para desempleados

**Volkshochschule (VHS)** (Universidad popular)
- URL varía por ciudad:
  - Zürich: https://vhszh.ch
  - Luzern: https://www.vhslu.ch
  - Bern: https://www.vhs-bern.ch
- Precio: CHF 400-600 por nivel
- **Ventaja:** Más barato que Klubschule

**Goethe-Institut**
- URL: https://www.goethe.de/schweiz
- **Ubicaciones:** Zürich, Bern, Genève
- Precio: CHF 800-1,200 por nivel
- **Ventaja:** Certificado internacional (necesario para algunas profesiones)

**ECAP** (Fundación sindical)
- URL: https://www.ecap.ch
- Precio: CHF 300-500 (subvencionado)
- **Público:** Trabajadores inmigrantes
- **Tip:** Descuentos según ingresos

---

### Certificaciones Oficiales

**Goethe-Zertifikat** (Más reconocido)
- Niveles: A1, A2, B1, B2, C1, C2
- Precio examen: CHF 180-280 según nivel
- **Válido:** Toda la vida
- **Tip:** B1 suficiente para mayoría de trabajos

**telc Deutsch**
- Similar a Goethe
- Precio: CHF 150-250
- **Ventaja:** Más barato

**ÖSD** (Austriaco)
- Reconocido en Suiza
- Precio: CHF 170-260

---

## 🏠 VIVIENDA

### Portales de Alquiler

**Homegate.ch** ⭐ (Líder)
- URL: https://www.homegate.ch
- **Tipos:** Pisos, casas, habitaciones
- **Filtros:** Precio, m², cantón, fecha disponibilidad
- **Tip:** Activar alertas para nuevos anuncios (competencia alta)

**ImmoScout24.ch**
- URL: https://www.immoscout24.ch
- Similar a Homegate
- **Tip:** Usar ambos portales en paralelo

**WGzimmer.ch** ⭐ (Habitaciones compartidas)
- URL: https://www.wgzimmer.ch
- **Función:** Habitaciones en pisos compartidos (WG)
- Precio: CHF 500-900/mes
- **Ventaja:** Más barato, conoces gente
- **Tip:** Enviar mensaje personalizado en alemán

**Newhome.ch**
- URL: https://www.newhome.ch
- **Especialidad:** Pisos nuevos

**Comparis.ch** (Comparador)
- URL: https://www.comparis.ch/immobilien
- Agrega múltiples portales

---

### Facebook Groups (Activos)

- "Wohnungen in Zürich" (50k+ miembros)
- "WG Zimmer Schweiz"
- "Expats in Switzerland - Housing"
- "Españoles en Suiza" (buscar sección vivienda)

---

### Consejos para Aplicar

**Dossier de aplicación debe incluir:**
1. CV (Lebenslauf)
2. Contrato de trabajo
3. Últimas 3 nóminas o carta del empleador
4. Betreibungsregisterauszug (registro de deudas)
   - **Dónde:** Gemeinde de tu cantón
   - **Precio:** CHF 20
   - **Función:** Demuestra que no tienes deudas
5. Copia del permiso B o L
6. Carta de presentación en alemán (opcional pero ayuda)

**Tip clave:** Los suizos alquilan al primero que aplica con dossier completo. Velocidad = éxito.

---

## 🚇 TRANSPORTE

### Transporte Público

**SBB Mobile** ⭐ (App oficial trenes)
- URL: https://www.sbb.ch
- **App:** iOS y Android
- **Función:**
  - Comprar billetes
  - Horarios en tiempo real
  - Abonos mensuales/anuales
- **Tip:** Llega 2 min antes - los trenes suizos son PUNTUALES

**Precios:**
- Billete Zürich-Luzern: CHF 27 (ida)
- Abono mensual zona Zürich: CHF 85
- **Halbtax** (50% descuento): CHF 185/año
- **GA Travelcard** (ilimitado): CHF 3,860/año (solo si viajas mucho)

**ZVV** (Transporte Zürich)
- URL: https://www.zvv.ch
- App: iOS y Android
- **Función:** Metro, tram, bus en zona Zürich

---

### Bicicleta (Alternativa barata)

**PubliBike** (Bike sharing)
- URL: https://www.publibike.ch
- Precio: CHF 1/30 min
- **Ubicaciones:** Estaciones en todas las ciudades

**Comprar bicicleta usada:**
- Ricardo.ch (CHF 100-300)
- Tutti.ch
- Facebook Marketplace

**Consejo:** En Suiza, bicicleta = transporte serio. Carriles bici excelentes.

---

## 🛒 SUPERMERCADOS Y COMPRAS

### Supermercados (Orden: Barato → Caro)

**1. Lidl** ⭐ (Más barato)
- URL: https://www.lidl.ch
- Ahorro: -30% vs Coop/Migros
- **Productos:** Alemanes, buena calidad
- **Tip:** Ir jueves (nuevos productos)

**2. Aldi**
- URL: https://www.aldi-suisse.ch
- Similar a Lidl
- **Ventaja:** Productos bio baratos

**3. Denner**
- URL: https://www.denner.ch
- Ahorro: -20% vs Coop/Migros
- **Especialidad:** Bebidas alcohólicas baratas

**4. Migros**
- URL: https://www.migros.ch
- Precio: Medio
- **Ventaja:** Productos frescos, marcas blancas (M-Budget)
- **No vende:** Alcohol ni tabaco

**5. Coop**
- URL: https://www.coop.ch
- Precio: Medio-alto
- **Ventaja:** Calidad superior, todo tipo de productos

**6. Manor Food** (Supermercado gourmet)
- Precio: Caro
- **Solo para:** Caprichos

---

### Apps para Ahorrar

**Too Good To Go** ⭐
- URL: https://toogoodtogo.com
- **Función:** Comida de restaurantes/supermercados cerca de caducidad
- Precio: CHF 3-6 por "Magic Box" (valor CHF 12-20)
- **Tip:** Reservar por la tarde para recoger 20:00-21:00

**Doodle** (Comparador precios)
- URL: https://doodle.ch
- **Función:** Compara precios entre Migros, Coop, Aldi, Lidl
- **Tip:** Planifica compra semanal para ahorrar CHF 50-100/mes

**Migros App**
- Cupones descuento semanales
- Puntos Cumulus (cashback)

**Coop App**
- Cupones Supercard
- Ofertas personalizadas

---

## 👥 COMUNIDADES Y GRUPOS

### Facebook Groups (Hispanohablantes)

**Españoles en Suiza** (20k+ miembros) ⭐
- Muy activo
- **Temas:** Trabajo, vivienda, trámites, networking
- **Tip:** Leer las guías fijadas (FAQ)

**Latinos en Zürich** (8k+ miembros)
- Eventos sociales
- Ayuda entre latinos

**HispanosEnSuiza** (Oficial - 5k+) ⭐
- URL: https://www.facebook.com/groups/hispanoensuiza
- **Creador:** Comunidad verificada
- **Contenido:** Guías actualizadas 2026

**Argentinos en Suiza** (3k+)
- Específico para argentinos

**Colombianos en Suiza** (2k+)
- Específico para colombianos

**Mexicanos en Suiza** (1.5k+)
- Específico para mexicanos

---

### Telegram Groups

**Españoles Zürich** (500+ miembros)
- Búsqueda: @espanoleszurich
- Muy activo, ayuda diaria

**Latinos Suiza** (300+ miembros)
- Networking y eventos

---

### Reddit

**r/Switzerland** (200k+ miembros)
- URL: https://www.reddit.com/r/Switzerland
- Idioma: Inglés
- **Uso:** Preguntas generales

**r/askswitzerland** (50k+ miembros)
- URL: https://www.reddit.com/r/askswitzerland
- **Función:** Q&A específicas sobre mudarse a Suiza

---

### Meetup.com (Eventos presenciales)

**Internations Zürich**
- URL: https://www.internations.org/zurich
- Eventos mensuales para expatriados
- **Precio:** Gratis/premium CHF 7/mes

**Zürich Expats Meetup**
- URL: https://www.meetup.com (buscar "Zurich expats")
- Eventos deportivos, afterwork, excursiones

---

## 📲 APPS ESENCIALES SUIZA

### Pagos

**Twint** ⭐ (App de pagos suiza)
- URL: https://www.twint.ch
- **Función:** Pagar en tiendas, entre amigos, parking
- **Requisitos:** Cuenta bancaria suiza
- **Uso:** 80% de suizos lo usan - ESENCIAL
- **Tip:** Instalar apenas tengas cuenta Neon/Zak

---

### Clima

**MeteoSwiss** (Oficial)
- URL: https://www.meteoswiss.admin.ch
- App: iOS y Android
- **Ventaja:** Pronóstico más preciso de Suiza

---

### Emergencias

**Sirene** (Alertas emergencias)
- URL: https://www.alert.swiss
- **Función:** Alertas de protección civil
- **Tip:** En Suiza hay simulacros anuales (primer miércoles febrero)

**EchoSOS** (Llamadas emergencia)
- **Función:** Llama automáticamente al 144 (ambulancia) con tu ubicación GPS

---

### Reciclaje

**ZüriWie** (Solo Zürich)
- **Función:** Horarios recogida basura, puntos reciclaje
- **Tip:** En Suiza el reciclaje es OBLIGATORIO (multas si no lo haces)

**Recycling Map**
- URL: https://recycling-map.ch
- **Función:** Encuentra puntos de reciclaje por tipo (vidrio, PET, cartón)

---

### Salud

**MediService** (App de tu seguro)
- Cada aseguradora tiene su app (Assura, Swica, Helsana...)
- **Función:** Ver facturas, enviar recetas, chat con médico

**Well**
- Telemedicina - consulta médica online CHF 39
- **Útil:** Emergencias leves (gripe, dolor de garganta)

---

### Compras

**Galaxus** (Amazon suizo)
- URL: https://www.galaxus.ch
- **Función:** Electrónica, hogar, deporte
- **Ventaja:** Envío 24h gratis >CHF 50

**Ricardo** (eBay suizo)
- URL: https://www.ricardo.ch
- **Función:** Compraventa segunda mano
- **Tip:** Excelente para amueblar piso barato

**Tutti** (Wallapop suizo)
- URL: https://www.tutti.ch
- Segunda mano local

---

## 🏛️ WEBS OFICIALES GOBIERNO

**ch.ch** ⭐ (Portal oficial Confederación Suiza)
- URL: https://www.ch.ch
- **Función:** Información oficial sobre TODO
- Idiomas: Alemán, francés, italiano, inglés
- **Temas:** Permisos, impuestos, seguros, derechos

**SEM** (Secretaría de Migraciones)
- URL: https://www.sem.admin.ch
- **Función:** Información permisos L, B, C
- **Tip:** Consultar plazos de tramitación por país

**SUVA** (Seguro accidentes)
- URL: https://www.suva.ch
- **Función:** Información sobre seguro accidentes laborales
- **Teléfono:** +41 41 419 58 51

**BFS** (Estadísticas oficiales)
- URL: https://www.bfs.admin.ch
- **Función:** Salarios promedio, coste de vida, datos demográficos

---

## 💰 IMPUESTOS

**Estudio Tributario**
- URL: https://www.estv.admin.ch (Administración Federal Contribuciones)
- **Función:** Calculadora impuestos por cantón
- **Tip:** Zürich ~15-18%, Zug ~10% (más bajo), Genève ~20% (más alto)

**Tax Calculator**
- URL: https://www.comparis.ch/steuern/steuerrechner
- **Función:** Simula tu carga fiscal según cantón y salario
- **Tip:** Importante para decidir dónde vivir

---

## 🚗 LICENCIA DE CONDUCIR

**Strassenverkehrsamt (Oficina Circulación)** - varía por cantón
- Zürich: https://www.stva.zh.ch
- Luzern: https://vd.lu.ch
- **Plazo:** 12 meses desde llegada para cambiar licencia extranjera
- **Costo:** CHF 50-150 según cantón
- **Documentos:** Licencia original, permiso B, foto, formulario

---

## 📚 RECURSOS ADICIONALES

### YouTube Channels

**"Swiss German for Beginners"**
- Tutoriales Schweizerdeutsch con subtítulos

**"Simple Switzerland"**
- Tips de vida en Suiza en inglés

---

### Podcasts

**"Die Newcomer"** (SRF)
- Historias de inmigrantes en Suiza
- Idioma: Alemán (nivel B1-B2)

---

### Blogs

**englishforum.ch**
- URL: https://www.englishforum.ch
- **Función:** Foro de expatriados en inglés
- **Temas:** Mudanza, finanzas, vida social

---

## ✅ CHECKLIST DE RECURSOS - PRIMEROS 30 DÍAS

**DÍA 1:**
- [ ] Instalar SBB Mobile
- [ ] Instalar MeteoSwiss
- [ ] Unirse a grupo Facebook "Españoles en Suiza"

**SEMANA 1:**
- [ ] Crear cuenta LinkedIn en alemán
- [ ] Registrarse en jobs.ch + indeed.ch
- [ ] Configurar alertas de empleo

**SEMANA 2:**
- [ ] Abrir cuenta Neon
- [ ] Instalar Twint
- [ ] Comparar seguros en priminfo.ch

**SEMANA 3:**
- [ ] Registrarse en Migros Klubschule (alemán)
- [ ] Descargar Duolingo
- [ ] Buscar WG en wgzimmer.ch

**SEMANA 4:**
- [ ] Instalar Too Good To Go
- [ ] Buscar punto reciclaje más cercano
- [ ] Configurar app de tu seguro médico

---

## 🎯 ATAJOS ESENCIALES

**Top 5 Webs que DEBES conocer:**
1. **jobs.ch** → Trabajo
2. **priminfo.ch** → Seguro médico
3. **homegate.ch** → Vivienda
4. **ch.ch** → Info oficial
5. **sbb.ch** → Transporte

**Top 5 Apps que DEBES instalar:**
1. **Twint** → Pagos
2. **SBB Mobile** → Trenes
3. **Neon** → Banco
4. **Too Good To Go** → Comida barata
5. **DeepL** → Traductor alemán

---

## 📞 NÚMEROS DE EMERGENCIA

- **Emergencias médicas:** 144
- **Policía:** 117
- **Bomberos:** 118
- **Emergencia general (UE):** 112
- **Intoxicaciones:** 145
- **Ayuda psicológica (24h):** 143 (Die Dargebotene Hand)

---

## 🔄 ÚLTIMA ACTUALIZACIÓN

**Versión:** 2.0
**Fecha:** Noviembre 2026
**Verificado:** Todos los links activos y precios actualizados

**Próxima revisión:** Febrero 2027

---

*Directorio creado por Swiss Starter Pack - HispanosEnSuiza*
*¿Encontraste un link roto o información desactualizada? Contáctanos: info@hispanoensuiza.com*

---

## 💡 CÓMO USAR ESTE DIRECTORIO

**Método recomendado:**
1. **Guárdalo offline** (PDF en tu móvil)
2. **Marca los recursos** que uses con ⭐
3. **Actualízalo** con tus propios hallazgos
4. **Compártelo** con otros hispanohablantes

**Este documento es un mapa.** Tu éxito depende de cómo lo uses. No leas todo - usa lo que necesitas AHORA.

**Regla 80/20:** El 80% del valor está en el 20% de los recursos:
- jobs.ch
- Neon
- priminfo.ch
- SBB Mobile
- Grupo Facebook "Españoles en Suiza"

Empieza por ahí. El resto, según necesites.

¡Buena suerte en tu aventura suiza! 🇨🇭
